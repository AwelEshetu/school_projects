<?php

echo ("hello");

$userid = $_GET['userid'];
echo ("$userid\n\n");

?>