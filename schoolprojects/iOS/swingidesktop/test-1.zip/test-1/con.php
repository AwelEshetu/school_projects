<?php
$host = "localhost"; 
$user = "swengi11"; 
$pass = "swengi11"; 
$db = "supercali"; 
?>