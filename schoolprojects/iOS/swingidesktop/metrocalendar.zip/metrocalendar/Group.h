//
//  Group.h
//  pushCalendar
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Event, User;

@interface Group : NSManagedObject

@property (nonatomic, retain) NSNumber * groupID;
@property (nonatomic, retain) NSString * groupName;
@property (nonatomic, retain) NSSet *groupsToUser;
@property (nonatomic, retain) NSSet *groupToEvents;
@end

@interface Group (CoreDataGeneratedAccessors)

- (void)addGroupsToUserObject:(User *)value;
- (void)removeGroupsToUserObject:(User *)value;
- (void)addGroupsToUser:(NSSet *)values;
- (void)removeGroupsToUser:(NSSet *)values;

- (void)addGroupToEventsObject:(Event *)value;
- (void)removeGroupToEventsObject:(Event *)value;
- (void)addGroupToEvents:(NSSet *)values;
- (void)removeGroupToEvents:(NSSet *)values;

@end
