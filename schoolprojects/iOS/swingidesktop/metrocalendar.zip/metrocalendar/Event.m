//
//  Event.m
//  pushCalendar
//
//  Created by iosdev on 11/30/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Event.h"
#import "Group.h"
#import "User.h"


@implementation Event

@dynamic address;
@dynamic date;
@dynamic endTime;
@dynamic eventDescription;
@dynamic eventID;
@dynamic location;
@dynamic startTime;
@dynamic title;
@dynamic endDate;
@dynamic creator;
@dynamic eventToGroup;

@end
