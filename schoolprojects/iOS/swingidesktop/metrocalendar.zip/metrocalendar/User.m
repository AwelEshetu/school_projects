//
//  User.m
//  pushCalendar
//
//  Created by iosdev on 12/9/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "User.h"
#import "Event.h"
#import "Group.h"


@implementation User

@dynamic email;
@dynamic firstName;
@dynamic lastName;
@dynamic password;
@dynamic token;
@dynamic userID;
@dynamic events;
@dynamic userToGroups;

@end
