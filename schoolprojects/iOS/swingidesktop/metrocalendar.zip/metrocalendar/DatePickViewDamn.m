//
//  DatePickView.m
//  pushCalendar
//
//  Created by iosdev on 11/30/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "DatePickViewDamn.h"
#import "AddEvent.h"

@implementation DatePickViewDamn
@synthesize addEventVc;
@synthesize StartD, EndD;
@synthesize StartDatePicker;
@synthesize sDate,sTime,eDate,eTime;

-(IBAction)back
{
    [ self dismissModalViewControllerAnimated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}







-(IBAction)SaveStartTime:(id)Sender{
    
    NSLog(@"data is saved");
    //saving selection of picker view in lebel
    NSLocale *usLocale = [[NSLocale alloc]
                          initWithLocaleIdentifier:@"en_US"]  ;
    
    NSDate *startDate = [StartDatePicker date];
    NSString *selectionString3 = [[NSString alloc] initWithFormat:@"%@",
                                  [startDate descriptionWithLocale:usLocale]];
	
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"YYYY-MM-dd"];
	
    NSDateFormatter *dateFormat2 = [[NSDateFormatter alloc]init];
    [dateFormat2 setDateFormat:@"YYYYMMdd"];
	NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
	[timeFormat setDateFormat:@"HH:mm:ss"];
	
	//NSString *theSDate = [dateFormat stringFromDate:startDate];
	NSString *theSTime = [timeFormat stringFromDate:startDate];
    
	NSString *theSDate = [dateFormat stringFromDate:startDate];
    NSString *tempDate = [dateFormat2 stringFromDate:startDate];
    if([StartDatePicker.date timeIntervalSinceNow]<-10){
    }
    else{
        addEventVc.startDate.text = [NSString stringWithFormat:@"%@", theSDate];
        addEventVc.startTime.text = [NSString stringWithFormat:@"%@", theSTime];
        sDate.text = [NSString stringWithFormat:@"%@", theSDate];
        sTime.text=[NSString stringWithFormat:@"%@", theSTime];
        checkTime =theSTime;
        checkDate = tempDate;
    }
    NSLog(@"check start date %@",tempDate);
	StartD.text = @"Start Date Saved";
    NSLog(@"check %@%@\n",selectionString3,theSDate);
    
}

-(IBAction)SaveEndTime:(id)Sender{
    int startTime;
    int endTime;
    int checkendDate;
    int checkStartDate;
    NSLog(@"data is saved");
    //saving selection of picker view in lebel
    NSLocale *usLocale = [[NSLocale alloc]
                          initWithLocaleIdentifier:@"en_US"]  ;
    
    NSDate *endDate = [StartDatePicker date];
    NSString *selectionString3 = [[NSString alloc] initWithFormat:@"%@",
                                  [endDate descriptionWithLocale:usLocale]];
	
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    [dateFormat1 setDateFormat:@"YYYY-MM-dd"];
    
    NSDateFormatter *dateFormat2 = [[NSDateFormatter alloc]init];
    [dateFormat2 setDateFormat:@"YYYYMMdd"];
	
	NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
	[timeFormat setDateFormat:@"HH:mm:ss"];
	
    NSString *theSDate1 = [dateFormat1 stringFromDate:endDate];
	NSString *theETime = [timeFormat stringFromDate:endDate];
    NSString *tempDate = [dateFormat2 stringFromDate:endDate];
    checkendDate = [tempDate intValue];
	startTime = [checkTime intValue];
    endTime = [theETime intValue];
    checkStartDate = [checkDate intValue];
    
    NSLog(@"check date %d %d",checkStartDate,checkendDate);
    
    addEventVc.endDate.text = [NSString stringWithFormat:@"%@", theSDate1];
    
    if([StartDatePicker.date timeIntervalSinceNow]<-5){
        eTime.text = @"Time";
        eDate.text =  @"End Date";
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Later Date and Time is not accepted. Select again "
                                                       delegate:self cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
        
    }
    else{
        if(checkStartDate<checkendDate){
            
            
            eDate.text = [NSString stringWithFormat:@"%@ ", theSDate1];
            
            
            addEventVc.endTime.text = [NSString stringWithFormat:@"%@ ", theETime];
            eTime.text = [NSString stringWithFormat:@"%@ ", theETime];
            
            
        }
        else if(checkStartDate == checkendDate){
            eTime.text = @"Time";
            eDate.text =  @"End Date";
            addEventVc.endTime.text = [NSString stringWithFormat:@"%@", theETime];
            if(endTime>=startTime){
                eDate.text = [NSString stringWithFormat:@"%@ ", theSDate1];
                eTime.text = [NSString stringWithFormat:@"%@ ", theETime];
            }
            else {
                
                eTime.text = @"Time";
                eDate.text =  @"End Date";
                
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                                message:@"Later Date and Time is not accepted. Select again "
                                                               delegate:self cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
                [alert show];
                
                
            }
            
            
        }
    }
    
    
	//[dateFormat release];
    
	
    
	EndD.text = @"Start Date Saved";
    NSLog(@"%@",selectionString3);
    
}



#pragma mark - View lifecycle

- (void)viewDidLoad
{
    StartDatePicker.date = [NSDate date];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
