//
//  DatePickView.h
//  pushCalendar
//
//  Created by iosdev on 11/30/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AddEvent;

@interface DatePickViewDamn : UIViewController<UIPickerViewDelegate>
{
    IBOutlet UILabel *sDate;
    IBOutlet UILabel *sTime;
    IBOutlet UILabel *eDate;
    IBOutlet UILabel *eTime;
    NSDate *TodaysDate;
    NSString *checkTime;
    NSString *checkDate;
    
}

@property (nonatomic, strong) AddEvent *addEventVc;
@property (nonatomic, strong) UILabel *StartD;
@property (nonatomic, strong) UILabel *EndD;
@property (nonatomic, strong) IBOutlet UIDatePicker *StartDatePicker;
@property (nonatomic, strong) UILabel *sDate;
@property (nonatomic, strong) UILabel *sTime;
@property (nonatomic, strong) UILabel *eDate;
@property (nonatomic, strong) UILabel *eTime;

-(IBAction)SaveStartTime:(id)Sender;
-(IBAction)SaveEndTime:(id)Sender;
-(IBAction)back;

@end
