//
//  Group.m
//  pushCalendar
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Group.h"
#import "Event.h"
#import "User.h"


@implementation Group

@dynamic groupID;
@dynamic groupName;
@dynamic groupsToUser;
@dynamic groupToEvents;

@end
