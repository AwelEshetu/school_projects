//
//  pushCalendarTests.m
//  pushCalendarTests
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "pushCalendarTests.h"

@implementation pushCalendarTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in pushCalendarTests");
}

@end
