//
//  pushCalendarTests.h
//  pushCalendarTests
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface pushCalendarTests : SenTestCase

@end
