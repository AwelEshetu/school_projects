//
//  PickerViewController.m
//  test
//
//  Created by iosdev on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PickerViewController.h"

@implementation PickerViewController
@synthesize av;
@synthesize StartD;
@synthesize StartDatePicker;




-(IBAction)SaveStartTime:(id)Sender{
    
    NSLog(@"data is saved");
    //saving selection of picker view in lebel
    NSLocale *usLocale = [[NSLocale alloc]
                           initWithLocaleIdentifier:@"en_US"] ;
    
    NSDate *startDate = [StartDatePicker date];
    NSString *selectionString3 = [[NSString alloc] initWithFormat:@"%@",
                                  [startDate descriptionWithLocale:usLocale]];
	
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"YYY-MM-dd"];
	
	NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
	[timeFormat setDateFormat:@"HH:mm:ss"];
	
	NSString *theSDate = [dateFormat stringFromDate:startDate];
	NSString *theSTime = [timeFormat stringFromDate:startDate];
	
   	av.startTimeText.text = [NSString stringWithFormat:@"%@ ", theSDate];
    //esvc.startTimeText.text = [NSString stringWithFormat:@"%@ ", theSTime];

	StartD.text = @"Start Date Saved";
}

-(IBAction)SaveEndTime:(id)Sender{
    
    NSLog(@"data is saved");
    //saving selection of picker view in lebel
    NSLocale *usLocale = [[NSLocale alloc]
                           initWithLocaleIdentifier:@"en_US"] ;
    
    NSDate *endDate = [StartDatePicker date];
    NSString *selectionString3 = [[NSString alloc] initWithFormat:@"%@",
                                  [endDate descriptionWithLocale:usLocale]];
	
    //	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    //	[dateFormat setDateFormat:@"YYY-MM-dd"];
	
	NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
	[timeFormat setDateFormat:@"HH:mm:ss"];
	
    //	NSString *theSDate = [dateFormat stringFromDate:startDate];
	NSString *theETime = [timeFormat stringFromDate:endDate];
	
    //   	esvc.dateText.text = [NSString stringWithFormat:@"%@ ", theSDate];
    av.endTimeText.text = [NSString stringWithFormat:@"%@ ", theETime];
	//[dateFormat release];
	EndD.text = @"Start Date Saved";
}




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2 ;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return 5;
}


@end
