//
//  AddEvent.m
//  pushCalendar
//
//  Created by iosdev on 11/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddEvent.h"
#import "DatePickViewDamn.h"

#import "SecondViewController.h"
#import "AppDelegate.h"

@implementation AddEvent

@synthesize titleText;
@synthesize descripText;
@synthesize receivedData;
@synthesize foundString;
@synthesize cVc;
@synthesize svc;
@synthesize myEventId;
@synthesize Address;
@synthesize scrollView;
@synthesize Addresses;
@synthesize appDelegate;
@synthesize startDate,startTime,endDate,endTime,eventEndDate;



-(IBAction)pickdate
{
    //[self presentModalViewController:datepickview animated:YES];
}

-(IBAction)repeatevent
{
    //[self presentModalViewController:repeatevent animated:YES];
}




-(IBAction)removeKeyboard:(id)sender{
    
    [titleText resignFirstResponder];
    [descripText resignFirstResponder];
}
-(BOOL) textView:(UIView *) textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if([text isEqualToString:@"\n"]){
        [textView resignFirstResponder];
        return NO;
    }
    else
        return YES;
    }


#pragma mark- Send Data to server

-(NSMutableString *)createXML:(NSString *) xmldata
{    
    
        NSMutableString *data1 = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n"];
    [data1 appendString:@"<calendar>\n"];
    [data1 appendString:@"\t<event>\n"];
    [data1 appendString:@"\t\t<event_id></event_id>\n"];
    [data1 appendString:@"\t\t<title>"];    
    [data1 appendString:title];
    [data1 appendString:@"</title>\n"];
    [data1 appendString:@"\t\t<venue_id>1</venue_id>\n"];
    [data1 appendString:@"\t\t<contact_id>1</contact_id>\n"];
    [data1 appendString:@"\t\t<description>"];
    [data1 appendString:description];
    [data1 appendString:@"</description>\n"];
    [data1 appendString:@"\t\t<category_id>1</category_id>\n"];
    [data1 appendString:@"\t\t<user_id>"];
    [data1 appendString:test];
    [data1 appendString:@"</user_id>\n"];
    [data1 appendString:@"\t\t<group_id>1</group_id>\n"];
    [data1 appendString:@"\t\t<status_id>1</status_id>\n"];
    [data1 appendString:@"\t\t<date>"];
    [data1 appendString:eventDate];
    [data1 appendString:@"</date>\n"];
    [data1 appendString:@"\t\t<starttime>"];
    [data1 appendString:eventStartTime];
    [data1 appendString:@"</starttime>\n"];
    [data1 appendString:@"\t\t<endDate>"];
    [data1 appendString:eventEndDate];
    [data1 appendString:@"</endDate>\n"];
    [data1 appendString:@"\t\t<endtime>"];
    [data1 appendString:eventEndTime];
    [data1 appendString:@"</endtime>\n"];
    [data1 appendString:@"\t</event>\n"];
    [data1 appendString:@"</calendar>\n"];
    NSLog(@" %@",data1);
    
    return data1;
}
-(void)XmlSend
{
    
    NSError *error = nil;
    NSString *targetURL= @"http://ec2-204-236-207-173.compute-1.amazonaws.com/test/EventInput.php";
    NSURLResponse *response;
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:targetURL]];
    NSMutableString *params = [NSMutableString stringWithString:@"calendar="];
    [params appendString:[self createXML:nil]];
    NSLog(@"params = %@",params);
    
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"my request%@",request);
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    NSString *responseData= [[NSString alloc] initWithData:[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error] encoding:NSUTF8StringEncoding];
    
    NSLog(@"response %@",responseData);
    [Response setText: responseData];
    // Response.text=responseData;
    serverResponse=responseData;
}

- (void)parseData:(NSData *)data {
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
	[parser setDelegate:self]; // The parser calls methods in this class
	[parser setShouldProcessNamespaces:NO]; // We don't care about namespaces
	[parser setShouldReportNamespacePrefixes:NO]; //
	[parser setShouldResolveExternalEntities:NO]; // We just want data, no other stuff
	[parser parse]; // Parse that data..
}

-(void)createEventLocally{


    title = titleText.text;
    description = descripText.text;
    eventDate = startDate.text;
    eventStartTime = startTime.text;
    eventEndTime = endTime.text;
    eventEndDate = endDate.text;
    Addresses = Address.text;
    
    
    NSDateFormatter *formate1 = [[NSDateFormatter alloc] init];  
    [formate1 setDateFormat:@"HH:mm:ss"];  
    NSDate *Time = [formate1 dateFromString:eventDate];  
    NSLog(@"Output :%@",Time);
    
    //for fixing id problems only for the time beings it should be changed latter
    intId++;
    myEventId = [NSNumber numberWithInt:intId];
    NSLog(@"my int value%@",myEventId);
    if ([titleText.text isEqual:@""]) {
        NSLog(@"Title is empty");
        UIAlertView *authentic = [[UIAlertView alloc] initWithTitle:@"Insert the title" message:serverResponse delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [authentic show];
    }else if([descripText.text isEqual:@""]){
        NSLog(@"Description is empty");
        UIAlertView *authentic = [[UIAlertView alloc] initWithTitle:@"Insert the description" message:serverResponse delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [authentic show];
    }else if ([Address.text isEqual:@""]){
        NSLog(@"Insert the address");
        UIAlertView *authentic = [[UIAlertView alloc] initWithTitle:@"Insert the address" message:serverResponse delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [authentic show];
    }else{
        
        appDelegate =(AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *context = [appDelegate managedObjectContext];
        NSManagedObject *event;
        
        event = [NSEntityDescription insertNewObjectForEntityForName:@"Event" inManagedObjectContext:context];
        [event setValue:myEventId forKey:@"eventID"];
        [event setValue:title forKey:@"title"];
        [event setValue:description forKey:@"eventDescription"];
        [event setValue:eventDate forKey:@"date"];
        [event setValue:eventStartTime forKey:@"startTime"];
        [event setValue:eventEndTime forKey:@"endTime"];
        [event setValue:Addresses forKey:@"address"];
        NSError *error;
        [context save:&error];
    }
}
-(IBAction)sendData:(id)sender
{
        
    if (conUserId == 0) 
    {
        NSLog(@" %@ is empty", conUserId);
        UIAlertView *alert = 
        [[UIAlertView alloc] initWithTitle:@"Your not logged in event is saved locally" 
                                   message:serverResponse 
                                  delegate:self 
                         cancelButtonTitle:@"OK" 
                         otherButtonTitles:nil];    
        
        [alert show]; 
        [self createEventLocally];
    }
    else
    {
            [self createEventLocally];
        
            [self createXML:nil];
            [self XmlSend];
            
            UIAlertView *alert = 
            [[UIAlertView alloc] initWithTitle:@"Data Saved to Database" 
                                       message:serverResponse 
                                      delegate:self 
                             cancelButtonTitle:@"OK" 
                             otherButtonTitles:nil];    
            
            [alert show]; 
        }
        [self.navigationController popViewControllerAnimated:YES];
    }   


-(IBAction) SelectS:(id)sender{
	NSLog(@"begin editing");
	DatePickViewDamn *pickerViewController = [[DatePickViewDamn alloc] initWithNibName:@"DatePickViewDamn" bundle:nil];
    // ...
    // Pass the selected object to the new view controller.
	pickerViewController.addEventVc = self;
    
    [self presentModalViewController:pickerViewController animated:YES];
}


/*- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
 {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization
 }
 return self;
 }*/

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    //[super viewDidLoad];
    
    scrollView.frame = CGRectMake(0, 0, 320, 460);
    [scrollView setContentSize:CGSizeMake(320, 678)];
    self.title=@"Create Event";
    //startDate.text =self;
    foundString = [[NSMutableString alloc] initWithCapacity:50];
    [foundString appendString:@"Event_id:"];
       NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://ec2-204-236-207-173.compute-1.amazonaws.com/test/pull_data2.php"]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
    if (theConnection) {
        receivedData = [NSMutableData data];
    } else {
        NSLog(@"nothing received");
    }
    
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSFetchRequest *UserRequest = [[NSFetchRequest alloc] init];
    NSManagedObjectContext *UserContext = [appDelegate managedObjectContext];
    NSEntityDescription *UserEntityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:[appDelegate managedObjectContext]];
    UserRequest = [[NSFetchRequest alloc]init];
    [UserRequest setEntity:UserEntityDesc];
    
    NSError *error1;
    NSManagedObject *matches1 = nil;
    NSArray *objects1 = [UserContext executeFetchRequest:UserRequest error:&error1];
    
    NSInteger countMatchObject1=[objects1 count];
    int counter1=0;
    NSMutableArray *arrayID1 = [[NSMutableArray alloc]init];
    
    while (countMatchObject1!=0) {
        matches1 = [objects1 objectAtIndex:counter1];
        counter1++;
        userid=[matches1 valueForKey:@"userID"];
        
        countMatchObject1--;
        
        
        [arrayID1 addObject:userid];
        
        
    }   
    NSLog(@"my ID is %@",userid);
    
    conUserId = [userid integerValue];
    
    test = [NSString stringWithFormat:@"%d", conUserId];
   

    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    
}
#pragma mark- XML parsing sent from server
// NSURLConnection will cal this method when it did receive resonse
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	[receivedData setLength:0];
}
// NSURLConnection will cal this method when it didReceiveData
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[receivedData appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	NSLog(@"Succeeded! Received %d bytes of data",[receivedData length]);
	[self parseData:receivedData];
}



// this will be called when parser starts inspecting a tag <tag>!!
-  (void)parser:(NSXMLParser *)parser 
didStartElement:(NSString *)elementName
   namespaceURI:(NSString *)namespaceURI 
  qualifiedName:(NSString *)qName
     attributes:(NSDictionary *)attributeDict {
    if ( [elementName isEqualToString:@"event"]   )  {
        myEventId = [NSNumber numberWithInt:[[attributeDict valueForKey:@"event_id"] integerValue]];
        //if([myEventId isEqualToNumber:myID]){
        // allowString = YES; 
        //}
        NSLog(@"Event id %@",myEventId); 
        
        intId = [myEventId integerValue];
        NSLog(@"int id %d",intId);
        
        //[foundString appendString:string];
        // if(string==@"10")
        //URL.text =  foundString ;
    }       
    
    
    
}








- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
