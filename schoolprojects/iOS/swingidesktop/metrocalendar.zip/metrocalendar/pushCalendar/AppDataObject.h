//
//  AppDataObject.h
//  pushCalendar
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDataObject : UIView

@end
