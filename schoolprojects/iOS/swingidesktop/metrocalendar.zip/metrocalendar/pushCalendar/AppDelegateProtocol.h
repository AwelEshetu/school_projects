//
//  AppDelegateProtocol.h
//  pushCalendar
//
//  Created by iosdev on 11/28/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AppDelegateProtocol <NSObject>

@end
