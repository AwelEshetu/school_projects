//
//  AddEvent.h
//  pushCalendar
//
//  Created by iosdev on 11/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CalendarView;
@class SecondViewController;
@class AppDelegate;

@interface AddEvent : UIViewController<NSXMLParserDelegate,UITextFieldDelegate>
{
    IBOutlet UITextField *titleText;
    IBOutlet UITextView *descripText;
    IBOutlet UITextField *Address;
    IBOutlet UILabel *Response;
    IBOutlet UILabel *startDate;
    IBOutlet UILabel *startTime;
    IBOutlet UILabel *endDate;
    IBOutlet UILabel *endTime;
    
    AppDelegate *appDelegate;
    
    SecondViewController *svc;
    
    NSString *serverResponse;
    NSString *title;
    NSString *description;
    NSString *eventDate;
    NSString *eventStartTime;
    NSString *eventEndTime;
    NSString *eventEndDate;
    NSInteger intId;
    NSNumber *myEventId;
    NSString *Addresses;
    NSString *userid;
    NSString *test;
    NSInteger conUserId;
    
    NSMutableString *foundString;
    NSMutableData *receivedData;
    IBOutlet UIScrollView *scrollView;
    
    CalendarView *cVc;
}

@property (nonatomic ,strong) UITextField *titleText; 
@property (nonatomic ,strong) UITextView *descripText; 
@property (nonatomic,strong) NSMutableString *foundString;
@property (nonatomic ,strong) NSMutableData *receivedData;
@property (nonatomic,strong) CalendarView *cVc;
@property (nonatomic,strong) SecondViewController *svc;
@property (nonatomic,strong) NSNumber *myEventId;
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic, strong) UITextField *Address;
@property (nonatomic, strong) NSString *Addresses;
@property (nonatomic, strong) AppDelegate *appDelegate;
@property (nonatomic, strong) UILabel *startTime;
@property (nonatomic, strong) UILabel *startDate;
@property (nonatomic, strong) UILabel *endDate;
@property (nonatomic, strong) UILabel *endTime;
@property (nonatomic, strong) NSString *eventEndDate;


-(IBAction)pickdate;
-(IBAction)sendData:(id)sender;
-(IBAction)removeKeyboard:(id)sender;
-(void)parseData:(NSData *)data;
-(IBAction)repeatevent;

@end
