//
//  JourneyPlanner.h
//  pushCalendar
//
//  Created by iosdev on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MapView;


@interface JourneyPlanner : UIViewController <NSXMLParserDelegate,UITableViewDelegate>
{
    
    IBOutlet UITextField *addressField;
    IBOutlet UITextField *addressFieldTo;
    IBOutlet UIButton *goButton;
    IBOutlet UITextField *time;
    NSXMLParser *xmlParser;
    NSString *elementname;
    NSMutableString *coords1;
    NSMutableString *coords2;
    int secondcords;
    BOOL boolean;
    NSMutableArray *firstRoute;
    NSMutableArray *secondRoute;
    NSMutableArray *thirdRoute;
    int intForRoutes;
    NSString *types;
    IBOutlet UITableView *table;
    NSMutableString *theTimeType;
    int hello;
    NSString *x;
    NSString *y;
    BOOL boolean2;
    BOOL booleanForTrasportType;
    NSString *transportType;
    int legs;
    NSMutableArray *xArray;
    NSMutableArray *yArray;
    NSMutableArray *bothCoordinates;
    
    NSMutableArray *bothCoordsTogether;
    NSMutableArray *bothCoordsTogether2;
    NSMutableArray *bothCoordsTogether3;
    
    NSMutableString *putcoordstogether;
    NSMutableString *something;
    
    NSMutableArray *coordinatesForFocusing;
    NSMutableArray *coordinatesForFocusing2;
    NSMutableArray *coordinatesForFocusing3;
    BOOL shapeBool;
    int selectedRow;
    MapView *mapView;
    
    
    
}
@property(nonatomic,strong) IBOutlet UITableView *table;
@property(nonatomic) int selectedRow;
@property(nonatomic,strong) NSMutableArray *bothCoordsTogether;
@property(nonatomic,strong) NSMutableArray *bothCoordsTogether2;
@property(nonatomic,strong) NSMutableArray *bothCoordsTogether3;
@property(nonatomic,strong) NSMutableArray *coordinatesForFocusing;
@property(nonatomic,strong) NSMutableArray *coordinatesForFocusing2;
@property(nonatomic,strong) NSMutableArray *coordinatesForFocusing3;
-(IBAction)searchAddress;
-(IBAction) back;
-(IBAction)timeType:(id)sender;

@end
