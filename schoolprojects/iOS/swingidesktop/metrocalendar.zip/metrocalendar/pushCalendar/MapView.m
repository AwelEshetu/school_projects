//
//  MapView.m
//  pushCalendar
//
//  Created by iosdev on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MapView.h"
#import "mapAnnotation.h"


@implementation MapView
@synthesize routeLine = _routeLine;
@synthesize routeLineView = _routeLineView;
@synthesize mapView = _mapView;
@synthesize checkrow;
@synthesize journeyplanner;
@synthesize bothCoordFromJourneyPlanner1,bothCoordFromJourneyPlanner2,bothCoordFromJourneyPlanner3;
@synthesize coordsForFocusFromJR,coordsForFocusFromJR2,coordsForFocusFromJR3;
@synthesize addToJR,addFromJR;

-(void)viewDidAppear:(BOOL)animated{
    
    if (checkrow == 1) {
        //        NSLog(@"PERKELE");
        //        NSLog(@"%@",bothCoordFromJourneyPlanner1);
        
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSString *string = [[bothCoordFromJourneyPlanner1 valueForKey:@"description"]componentsJoinedByString:@"#"];
        //    NSLog(@"%@",string);
        //    NSString * result = [[array valueForKey:@"description"] componentsJoinedByString:@""];
        NSScanner *theScanner;
        routesArray = [[NSMutableArray alloc]init];
        NSArray *testikase;
        theScanner = [NSScanner scannerWithString:string];
        NSLog(@"%@",string);
        
        
        if (overLays!=nil) {
            [_mapView removeOverlays:[overLays objectAtIndex:0]];
            [overLays removeAllObjects];
            overLays = nil;
        } 
        while ([theScanner isAtEnd] == NO)
        {
            NSString *walkTheWalk = nil;
            [theScanner scanUpToString:@"walk" intoString:nil];
            [theScanner scanString:@"walk" intoString:nil];
            if ([theScanner scanUpToString:@"something" intoString:&walkTheWalk]) {
                testikase = [walkTheWalk componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                //            NSLog(@"WALKING COORDINATES: %@",ribale);
                //            NSLog(@"%i",[ribale count]);
                
                
                if (!walkingLines) {
                    walkingLines = [[NSMutableArray alloc]init];
                }
                [walkingLines addObject:[self loadRoute]];
                
                //            NSLog(@"%@",walkingLines);
            }
            
        }
        
        theScanner = [NSScanner scannerWithString:string];
        while ([theScanner isAtEnd] == NO)
        {
            NSString *routesForTransports = nil;
            [theScanner scanUpToString:@"something" intoString:nil];
            [theScanner scanString:@"something" intoString:nil];
            if ([theScanner scanUpToString:@"walk" intoString:&routesForTransports]||[theScanner scanUpToString:@"something" intoString:&routesForTransports]) {
                testikase = [routesForTransports componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                
                if (!transports) {
                    transports = [[NSMutableArray alloc]init];
                }
                [transports addObject:[self loadRoute]];
                
                //            NSLog(@"%@",transports);
            }
            
        }
        i=0;
        i2=0;
        //if there is array with something in it remove it and the overlay 
        
        [self.mapView addOverlays:walkingLines];
        [self.mapView addOverlays:transports];
        //    NSLog(@"moikka %@",ribale);
        
        if (!overLays) {
            overLays = [[NSMutableArray alloc]init];
        } 
        [overLays addObject:[_mapView overlays]];
        
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSArray* startAnno = [[coordsForFocusFromJR objectAtIndex:0] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees longitude  = [[startAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees latitude = [[startAnno objectAtIndex:1] doubleValue];
        
        NSString *subtitle =[NSString stringWithFormat:@"%g",latitude];
        NSString *appString =[subtitle stringByAppendingFormat:@" , %g",longitude];
        NSString *secondAppString;
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        mapAnnotation *startAnnotation  = [[mapAnnotation alloc]initWithCoordinate:coordinate title:addFromJR subtitle:secondAppString endOrStart:@"leStart"];
        
        
        NSArray* endAnno = [[coordsForFocusFromJR lastObject] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees endlongitude  = [[endAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees endlatitude = [[endAnno objectAtIndex:1] doubleValue];
        
        NSString *secondSubtitle =[NSString stringWithFormat:@"%g",endlatitude];
        secondAppString =[secondSubtitle stringByAppendingFormat:@" , %g",endlongitude];
        
        CLLocationCoordinate2D endcoordinate = CLLocationCoordinate2DMake(endlatitude, endlongitude);
        mapAnnotation *endAnnotation  = [[mapAnnotation alloc]initWithCoordinate:endcoordinate title:addToJR subtitle:appString endOrStart:@"leEnd"];
        
        //put the start and end annotations to an array and add the annotations
        endAndStartAnnotation=[NSArray arrayWithObjects:startAnnotation,endAnnotation, nil];
        [self.mapView addAnnotations:endAndStartAnnotation];
        
        
        //[self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
        MKMapPoint northEastPoint; 
        MKMapPoint southWestPoint; 
        
        // create an array of points. 
        MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * coordsForFocusFromJR.count);
        
        for(int idx = 0; idx < coordsForFocusFromJR.count; idx++)
        {
            
            NSString* currentPointString = [coordsForFocusFromJR objectAtIndex:idx];
            NSArray* latitudeLongitudeArray = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
            
            CLLocationDegrees longitude  = [[latitudeLongitudeArray objectAtIndex:0] doubleValue];
            CLLocationDegrees latitude = [[latitudeLongitudeArray objectAtIndex:1] doubleValue];
            //        NSLog(@"latitude: %f",latitude);
            //        NSLog(@"longitude: %f",longitude);
            //        NSLog(@"counter: %i",idx);
            
            CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
            
            MKMapPoint point = MKMapPointForCoordinate(coordinate);
            
            
            
            if (idx == 0) {
                northEastPoint = point;
                southWestPoint = point;
            }
            else 
            {
                if (point.x > northEastPoint.x) 
                    northEastPoint.x = point.x;
                if(point.y > northEastPoint.y)
                    northEastPoint.y = point.y;
                if (point.x < southWestPoint.x) 
                    southWestPoint.x = point.x;
                if (point.y < southWestPoint.y) 
                    southWestPoint.y = point.y;
            }
            
            pointArr[idx] = point;
            
        }
        
        
        makeRectangleAroundRoute = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
        
        free(pointArr);
        [self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
        
        xmlParser = nil;
        secondcords = 0;
        legs = 0;
        elementname = nil;
        x = nil;
        y = nil;
        as = nil;
        xArray = nil;
        yArray = nil;
        putcoordstogether = nil;
        bothCoordinates = nil;
        bothCoordsTogether = nil;
        coords1 = nil;
        coords2 = nil;
        something = nil;
        _routeLineView=nil;
        walkingLines = nil;
        transports = nil;
        routesArray = nil;
        coordinatesForFocusing = nil;
        toLocationTextField.latitude = 0.0;
        toLocationTextField.longitude = 0.0;
        fromLocationTextField.longitude = 0.0;
        fromLocationTextField.latitude = 0.0;
        string = nil;
        checkrow = 0;
        bothCoordFromJourneyPlanner1 = nil;
        
    }
    if (checkrow == 2) {
        //        NSLog(@"PERKELE222222");
        //         NSLog(@"%@",bothCoordFromJourneyPlanner2);
        
        
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSString *string = [[bothCoordFromJourneyPlanner2 valueForKey:@"description"]componentsJoinedByString:@"#"];
        //    NSLog(@"%@",string);
        //    NSString * result = [[array valueForKey:@"description"] componentsJoinedByString:@""];
        NSScanner *theScanner;
        routesArray = [[NSMutableArray alloc]init];
        NSArray *testikase;
        theScanner = [NSScanner scannerWithString:string];
        NSLog(@"%@",string);
        
        
        if (overLays!=nil) {
            [_mapView removeOverlays:[overLays objectAtIndex:0]];
            [overLays removeAllObjects];
            overLays = nil;
        } 
        while ([theScanner isAtEnd] == NO)
        {
            NSString *walkTheWalk = nil;
            [theScanner scanUpToString:@"walk" intoString:nil];
            [theScanner scanString:@"walk" intoString:nil];
            if ([theScanner scanUpToString:@"something" intoString:&walkTheWalk]) {
                testikase = [walkTheWalk componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                //            NSLog(@"WALKING COORDINATES: %@",ribale);
                //            NSLog(@"%i",[ribale count]);
                
                
                if (!walkingLines) {
                    walkingLines = [[NSMutableArray alloc]init];
                }
                [walkingLines addObject:[self loadRoute]];
                
                //            NSLog(@"%@",walkingLines);
            }
            
        }
        
        theScanner = [NSScanner scannerWithString:string];
        while ([theScanner isAtEnd] == NO)
        {
            NSString *routesForTransports = nil;
            [theScanner scanUpToString:@"something" intoString:nil];
            [theScanner scanString:@"something" intoString:nil];
            if ([theScanner scanUpToString:@"walk" intoString:&routesForTransports]||[theScanner scanUpToString:@"something" intoString:&routesForTransports]) {
                testikase = [routesForTransports componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                
                if (!transports) {
                    transports = [[NSMutableArray alloc]init];
                }
                [transports addObject:[self loadRoute]];
                
                //            NSLog(@"%@",transports);
            }
            
        }
        i=0;
        i2=0;
        //if there is array with something in it remove it and the overlay 
        
        [self.mapView addOverlays:walkingLines];
        [self.mapView addOverlays:transports];
        //    NSLog(@"moikka %@",ribale);
        
        if (!overLays) {
            overLays = [[NSMutableArray alloc]init];
        } 
        [overLays addObject:[_mapView overlays]];
        
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSArray* startAnno = [[coordsForFocusFromJR2 objectAtIndex:0] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees longitude  = [[startAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees latitude = [[startAnno objectAtIndex:1] doubleValue];
        
        NSString *subtitle =[NSString stringWithFormat:@"%g",latitude];
        NSString *appString =[subtitle stringByAppendingFormat:@" , %g",longitude];
        NSString *secondAppString;
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        mapAnnotation *startAnnotation  = [[mapAnnotation alloc]initWithCoordinate:coordinate title:addFromJR subtitle:secondAppString endOrStart:@"leStart"];
        
        
        NSArray* endAnno = [[coordsForFocusFromJR2 lastObject] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees endlongitude  = [[endAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees endlatitude = [[endAnno objectAtIndex:1] doubleValue];
        
        NSString *secondSubtitle =[NSString stringWithFormat:@"%g",endlatitude];
        secondAppString =[secondSubtitle stringByAppendingFormat:@" , %g",endlongitude];
        
        CLLocationCoordinate2D endcoordinate = CLLocationCoordinate2DMake(endlatitude, endlongitude);
        mapAnnotation *endAnnotation  = [[mapAnnotation alloc]initWithCoordinate:endcoordinate title:addToJR subtitle:appString endOrStart:@"leEnd"];
        
        //put the start and end annotations to an array and add the annotations
        endAndStartAnnotation=[NSArray arrayWithObjects:startAnnotation,endAnnotation, nil];
        [self.mapView addAnnotations:endAndStartAnnotation];
        
        
        MKMapPoint northEastPoint; 
        MKMapPoint southWestPoint; 
        
        // create an array of points. 
        MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * coordsForFocusFromJR2.count);
        
        for(int idx = 0; idx < coordsForFocusFromJR2.count; idx++)
        {
            
            NSString* currentPointString = [coordsForFocusFromJR2 objectAtIndex:idx];
            NSArray* latitudeLongitudeArray = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
            
            CLLocationDegrees longitude  = [[latitudeLongitudeArray objectAtIndex:0] doubleValue];
            CLLocationDegrees latitude = [[latitudeLongitudeArray objectAtIndex:1] doubleValue];
            //        NSLog(@"latitude: %f",latitude);
            //        NSLog(@"longitude: %f",longitude);
            //        NSLog(@"counter: %i",idx);
            
            CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
            
            MKMapPoint point = MKMapPointForCoordinate(coordinate);
            
            
            
            if (idx == 0) {
                northEastPoint = point;
                southWestPoint = point;
            }
            else 
            {
                if (point.x > northEastPoint.x) 
                    northEastPoint.x = point.x;
                if(point.y > northEastPoint.y)
                    northEastPoint.y = point.y;
                if (point.x < southWestPoint.x) 
                    southWestPoint.x = point.x;
                if (point.y < southWestPoint.y) 
                    southWestPoint.y = point.y;
            }
            
            pointArr[idx] = point;
            
        }
        
        
        makeRectangleAroundRoute = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
        
        free(pointArr);
        [self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
        
        xmlParser = nil;
        secondcords = 0;
        legs = 0;
        elementname = nil;
        x = nil;
        y = nil;
        as = nil;
        xArray = nil;
        yArray = nil;
        putcoordstogether = nil;
        bothCoordinates = nil;
        bothCoordsTogether = nil;
        coords1 = nil;
        coords2 = nil;
        something = nil;
        _routeLineView=nil;
        walkingLines = nil;
        transports = nil;
        routesArray = nil;
        coordinatesForFocusing = nil;
        toLocationTextField.latitude = 0.0;
        toLocationTextField.longitude = 0.0;
        fromLocationTextField.longitude = 0.0;
        fromLocationTextField.latitude = 0.0;
        string = nil;
        
        checkrow = 0;
        bothCoordFromJourneyPlanner2 = nil;
    }
    
    if (checkrow == 3) {
        //        NSLog(@"PERKELE333333");
        //         NSLog(@"%@",bothCoordFromJourneyPlanner3);
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSString *string = [[bothCoordFromJourneyPlanner3 valueForKey:@"description"]componentsJoinedByString:@"#"];
        //    NSLog(@"%@",string);
        //    NSString * result = [[array valueForKey:@"description"] componentsJoinedByString:@""];
        NSLog(@"%@",string);
        NSScanner *theScanner;
        routesArray = [[NSMutableArray alloc]init];
        NSArray *testikase;
        theScanner = [NSScanner scannerWithString:string];
        
        
        if (overLays!=nil) {
            [_mapView removeOverlays:[overLays objectAtIndex:0]];
            [overLays removeAllObjects];
            overLays = nil;
        } 
        while ([theScanner isAtEnd] == NO)
        {
            NSString *walkTheWalk = nil;
            [theScanner scanUpToString:@"walk" intoString:nil];
            [theScanner scanString:@"walk" intoString:nil];
            if ([theScanner scanUpToString:@"something" intoString:&walkTheWalk]) {
                testikase = [walkTheWalk componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                //            NSLog(@"WALKING COORDINATES: %@",ribale);
                //            NSLog(@"%i",[ribale count]);
                
                
                if (!walkingLines) {
                    walkingLines = [[NSMutableArray alloc]init];
                }
                [walkingLines addObject:[self loadRoute]];
                
                //            NSLog(@"%@",walkingLines);
            }
            
        }
        
        theScanner = [NSScanner scannerWithString:string];
        while ([theScanner isAtEnd] == NO)
        {
            NSString *routesForTransports = nil;
            [theScanner scanUpToString:@"something" intoString:nil];
            [theScanner scanString:@"something" intoString:nil];
            if ([theScanner scanUpToString:@"walk" intoString:&routesForTransports]||[theScanner scanUpToString:@"something" intoString:&routesForTransports]) {
                testikase = [routesForTransports componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                
                if (!transports) {
                    transports = [[NSMutableArray alloc]init];
                }
                [transports addObject:[self loadRoute]];
                
                //            NSLog(@"%@",transports);
            }
            
        }
        i=0;
        i2=0;
        //if there is array with something in it remove it and the overlay 
        
        [self.mapView addOverlays:walkingLines];
        [self.mapView addOverlays:transports];
        //    NSLog(@"moikka %@",ribale);
        
        if (!overLays) {
            overLays = [[NSMutableArray alloc]init];
        } 
        [overLays addObject:[_mapView overlays]];
        
        if (endAndStartAnnotation != nil) {
            [_mapView removeAnnotations:endAndStartAnnotation];
            endAndStartAnnotation = nil;
        }
        
        NSArray* startAnno = [[coordsForFocusFromJR3 objectAtIndex:0] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees longitude  = [[startAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees latitude = [[startAnno objectAtIndex:1] doubleValue];
        
        NSString *subtitle =[NSString stringWithFormat:@"%g",latitude];
        NSString *appString =[subtitle stringByAppendingFormat:@" , %g",longitude];
        NSString *secondAppString;
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        mapAnnotation *startAnnotation  = [[mapAnnotation alloc]initWithCoordinate:coordinate title:addFromJR subtitle:secondAppString endOrStart:@"leStart"];
        
        
        NSArray* endAnno = [[coordsForFocusFromJR3 lastObject] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees endlongitude  = [[endAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees endlatitude = [[endAnno objectAtIndex:1] doubleValue];
        
        NSString *secondSubtitle =[NSString stringWithFormat:@"%g",endlatitude];
        secondAppString =[secondSubtitle stringByAppendingFormat:@" , %g",endlongitude];
        
        CLLocationCoordinate2D endcoordinate = CLLocationCoordinate2DMake(endlatitude, endlongitude);
        mapAnnotation *endAnnotation  = [[mapAnnotation alloc]initWithCoordinate:endcoordinate title:addToJR subtitle:appString endOrStart:@"leEnd"];
        
        //put the start and end annotations to an array and add the annotations
        endAndStartAnnotation=[NSArray arrayWithObjects:startAnnotation,endAnnotation, nil];
        [self.mapView addAnnotations:endAndStartAnnotation];
        
        
        MKMapPoint northEastPoint; 
        MKMapPoint southWestPoint; 
        
        // create an array of points. 
        MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * coordsForFocusFromJR3.count);
        
        for(int idx = 0; idx < coordsForFocusFromJR3.count; idx++)
        {
            
            NSString* currentPointString = [coordsForFocusFromJR3 objectAtIndex:idx];
            NSArray* latitudeLongitudeArray = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
            
            CLLocationDegrees longitude  = [[latitudeLongitudeArray objectAtIndex:0] doubleValue];
            CLLocationDegrees latitude = [[latitudeLongitudeArray objectAtIndex:1] doubleValue];
            //        NSLog(@"latitude: %f",latitude);
            //        NSLog(@"longitude: %f",longitude);
            //        NSLog(@"counter: %i",idx);
            
            CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
            
            MKMapPoint point = MKMapPointForCoordinate(coordinate);
            
            
            
            if (idx == 0) {
                northEastPoint = point;
                southWestPoint = point;
            }
            else 
            {
                if (point.x > northEastPoint.x) 
                    northEastPoint.x = point.x;
                if(point.y > northEastPoint.y)
                    northEastPoint.y = point.y;
                if (point.x < southWestPoint.x) 
                    southWestPoint.x = point.x;
                if (point.y < southWestPoint.y) 
                    southWestPoint.y = point.y;
            }
            
            pointArr[idx] = point;
            
        }
        
        
        makeRectangleAroundRoute = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
        
        free(pointArr);
        [self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
        
        xmlParser = nil;
        secondcords = 0;
        legs = 0;
        elementname = nil;
        x = nil;
        y = nil;
        as = nil;
        xArray = nil;
        yArray = nil;
        putcoordstogether = nil;
        bothCoordinates = nil;
        bothCoordsTogether = nil;
        coords1 = nil;
        coords2 = nil;
        something = nil;
        _routeLineView=nil;
        walkingLines = nil;
        transports = nil;
        routesArray = nil;
        coordinatesForFocusing = nil;
        toLocationTextField.latitude = 0.0;
        toLocationTextField.longitude = 0.0;
        fromLocationTextField.longitude = 0.0;
        fromLocationTextField.latitude = 0.0;
        
        checkrow = 0;
        bothCoordFromJourneyPlanner3 = nil;
        
        string = nil;
        
    }
}


-(IBAction)back
{
    xmlParser = nil;
    secondcords = 0;
    legs = 0;
    elementname = nil;
    x = nil;
    y = nil;
    as = nil;
    xArray = nil;
    yArray = nil;
    putcoordstogether = nil;
    bothCoordinates = nil;
    bothCoordsTogether = nil;
    coords1 = nil;
    coords2 = nil;
    something = nil;
    _routeLineView=nil;
    walkingLines = nil;
    transports = nil;
    routesArray = nil;
    coordinatesForFocusing = nil;
    toLocationTextField.latitude = 0.0;
    toLocationTextField.longitude = 0.0;
    fromLocationTextField.longitude = 0.0;
    fromLocationTextField.latitude = 0.0;
    
    checkrow = 0;
    bothCoordFromJourneyPlanner3 = nil;
    bothCoordFromJourneyPlanner1 = nil;
    bothCoordFromJourneyPlanner2 = nil;
    
    
    addressField.text=nil;
    addressFieldTo.text=nil;
    CLLocationCoordinate2D location;
    location.latitude = 64.9241100;
    location.longitude = 25.7481510;
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta = 10;
    span.longitudeDelta = 10;
    region.span = span;
    region.center = location;
    if (endAndStartAnnotation != nil) {
        [_mapView removeAnnotations:endAndStartAnnotation];
        endAndStartAnnotation = nil;
    }
    if (overLays!=nil) {
        [_mapView removeOverlays:[overLays objectAtIndex:0]];
        [overLays removeAllObjects];
        overLays=nil;
    }
    [self.mapView setRegion:region animated:YES];
    
    [self dismissModalViewControllerAnimated:YES];
}

//Hides the keyboard when 'go' button is pressed
-(IBAction)HideKeyBoard:(id)sender{
    [addressField resignFirstResponder];
    [addressFieldTo resignFirstResponder];
}
-(void)clear{
    
    addressField.text=nil;
    addressFieldTo.text=nil;
    CLLocationCoordinate2D location;
    location.latitude = 64.9241100;
    location.longitude = 25.7481510;
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta = 10;
    span.longitudeDelta = 10;
    region.span = span;
    region.center = location;
    if (endAndStartAnnotation != nil) {
        [_mapView removeAnnotations:endAndStartAnnotation];
        endAndStartAnnotation = nil;
    }
    if (overLays!=nil) {
        [_mapView removeOverlays:[overLays objectAtIndex:0]];
        [overLays removeAllObjects];
        overLays=nil;
    }
    [self.mapView setRegion:region animated:YES];
    
}

-(id) loadRoute{
    
    //    NSLog(@"coordinates: %@", bothCoordsTogether);
    NSLog(@"Count of the coordinates: %i",[bothCoordsTogether count]);
	// create an array of points. 
	MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * routesArray.count);
	
    NSLog(@"%@",routesArray);
	for(int idx = 0; idx < routesArray.count; idx++)
	{
        
		NSString* currentPointString = [routesArray objectAtIndex:idx];
		NSArray* latitudeLongitudeArray = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        
		CLLocationDegrees longitude  = [[latitudeLongitudeArray objectAtIndex:0] doubleValue];
		CLLocationDegrees latitude = [[latitudeLongitudeArray objectAtIndex:1] doubleValue];
        //        NSLog(@"latitude: %f",latitude);
        //        NSLog(@"longitude: %f",longitude);
        //        NSLog(@"counter: %i",idx);
        
		CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        
		MKMapPoint point = MKMapPointForCoordinate(coordinate);
        
        
		pointArr[idx] = point;
        
	}
    
    // create the polyline from the coordinate array
	self.routeLine = [MKPolyline polylineWithPoints:pointArr count:routesArray.count];
    
	free(pointArr);
    
    return self.routeLine;
    
    
}
-(void) zoomInOnRoute
{
	//[self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
    MKMapPoint northEastPoint; 
	MKMapPoint southWestPoint; 
	
	// create an array of points. 
	MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * coordinatesForFocusing.count);
	
	for(int idx = 0; idx < coordinatesForFocusing.count; idx++)
	{
        
		NSString* currentPointString = [coordinatesForFocusing objectAtIndex:idx];
		NSArray* latitudeLongitudeArray = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        
		CLLocationDegrees longitude  = [[latitudeLongitudeArray objectAtIndex:0] doubleValue];
		CLLocationDegrees latitude = [[latitudeLongitudeArray objectAtIndex:1] doubleValue];
        //        NSLog(@"latitude: %f",latitude);
        //        NSLog(@"longitude: %f",longitude);
        //        NSLog(@"counter: %i",idx);
        
		CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        
		MKMapPoint point = MKMapPointForCoordinate(coordinate);
        
        
        
		if (idx == 0) {
			northEastPoint = point;
			southWestPoint = point;
		}
		else 
		{
			if (point.x > northEastPoint.x) 
				northEastPoint.x = point.x;
			if(point.y > northEastPoint.y)
				northEastPoint.y = point.y;
			if (point.x < southWestPoint.x) 
				southWestPoint.x = point.x;
			if (point.y < southWestPoint.y) 
				southWestPoint.y = point.y;
		}
        
		pointArr[idx] = point;
        
	}
    
    
    makeRectangleAroundRoute = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
    
	free(pointArr);
	[self.mapView setVisibleMapRect:makeRectangleAroundRoute animated:YES];
    
}

// This method is called if you use addOverlay. Must be called by delegate?
- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
    
    
    MKOverlayView* overlayView;
    if (i==[walkingLines count]) {
        //        NSLog(@"i is: %i and WL count is: %i",i,[walkingLines count]);
        self.routeLineView = [[MKPolylineView alloc]initWithPolyline:[transports objectAtIndex:i2]];
        self.routeLineView.lineWidth = 3;
        self.routeLineView.fillColor = [UIColor blackColor];
        self.routeLineView.strokeColor = [UIColor redColor];
        self.routeLineView.lineCap = kCGLineCapRound;
        
        i2++;
    }
    if (i<[walkingLines count]) {
        
        
        self.routeLineView = [[MKPolylineView alloc] initWithPolyline:[walkingLines objectAtIndex:i]];
        self.routeLineView.lineWidth = 3;
        self.routeLineView.fillColor = [UIColor blackColor];
        self.routeLineView.strokeColor = [UIColor blackColor];
        self.routeLineView.lineCap = kCGLineCapRound;
        ++i;
    }
    //		}
    
    overlayView = self.routeLineView;
    
    //	}
	return overlayView;
    
}

- (IBAction) showAddress {
    
    //all the hassle with xml,reittiopas etc
    [self addressLocation];
    
    //Hide the keypad
	[addressField resignFirstResponder];
    
    //removes the annotations if there is annotations
    if (endAndStartAnnotation != nil) {
        [_mapView removeAnnotations:endAndStartAnnotation];
        endAndStartAnnotation = nil;
    }
    
    
    NSString *string = [[bothCoordsTogether valueForKey:@"description"]componentsJoinedByString:@"#"];
    //    NSLog(@"%@",string);
    //    NSString * result = [[array valueForKey:@"description"] componentsJoinedByString:@""];
    NSScanner *theScanner;
    routesArray = [[NSMutableArray alloc]init];
    NSArray *testikase;
    theScanner = [NSScanner scannerWithString:string];
    
    
    if (overLays!=nil) {
        [_mapView removeOverlays:[overLays objectAtIndex:0]];
        [overLays removeAllObjects];
        overLays = nil;
    } 
    
    if((toLocationTextField.latitude != 0.0 && toLocationTextField.longitude != 0.0) ||(fromLocationTextField.latitude != 0.0 && fromLocationTextField.longitude != 0.0)){
        mapAnnotation *startAnnotation;
        mapAnnotation *endAnnotation;
        
        NSString *subtitle =[NSString stringWithFormat:@"%g",toLocationTextField.latitude];
        NSString *appString =[subtitle stringByAppendingFormat:@" , %g",toLocationTextField.longitude];
        
        NSLog(@"toLocationTextField components: %g",toLocationTextField);
        startAnnotation  = [[mapAnnotation alloc]initWithCoordinate:fromLocationTextField title:addressField.text subtitle:appString endOrStart:@"leStart"];
        [self.mapView addAnnotation:startAnnotation];
        
        NSString *secondSubtitle =[NSString stringWithFormat:@"%g",fromLocationTextField.latitude];
        NSString *secondAppString =[secondSubtitle stringByAppendingFormat:@" , %g",fromLocationTextField.longitude];
        
        NSLog(@"fromLocationTextField components: %g",fromLocationTextField);
        endAnnotation  = [[mapAnnotation alloc]initWithCoordinate:toLocationTextField title:addressFieldTo.text subtitle:secondAppString endOrStart:@"leEnd"];  
        [self.mapView addAnnotation:endAnnotation];
        endAndStartAnnotation = [NSArray arrayWithObjects:startAnnotation,endAnnotation, nil];
    }
    
    else{
        
        while ([theScanner isAtEnd] == NO)
        {
            NSString *walkTheWalk = nil;
            [theScanner scanUpToString:@"walk" intoString:nil];
            [theScanner scanString:@"walk" intoString:nil];
            if ([theScanner scanUpToString:@"something" intoString:&walkTheWalk]) {
                testikase = [walkTheWalk componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                //            NSLog(@"WALKING COORDINATES: %@",ribale);
                //            NSLog(@"%i",[ribale count]);
                
                
                if (!walkingLines) {
                    walkingLines = [[NSMutableArray alloc]init];
                }
                [walkingLines addObject:[self loadRoute]];
                
                //            NSLog(@"%@",walkingLines);
            }
            
        }
        
        theScanner = [NSScanner scannerWithString:string];
        while ([theScanner isAtEnd] == NO)
        {
            NSString *routesForTransports = nil;
            [theScanner scanUpToString:@"something" intoString:nil];
            [theScanner scanString:@"something" intoString:nil];
            if ([theScanner scanUpToString:@"walk" intoString:&routesForTransports]||[theScanner scanUpToString:@"something" intoString:&routesForTransports]) {
                testikase = [routesForTransports componentsSeparatedByString:@"#"];
                routesArray = [NSMutableArray arrayWithArray:testikase];
                [routesArray removeObjectAtIndex:0];
                [routesArray removeLastObject];
                
                
                if (!transports) {
                    transports = [[NSMutableArray alloc]init];
                }
                [transports addObject:[self loadRoute]];
                
                //            NSLog(@"%@",transports);
            }
            
        }
        i=0;
        i2=0;
        //if there is array with something in it remove it and the overlay 
        
        [self.mapView addOverlays:walkingLines];
        [self.mapView addOverlays:transports];
        //    NSLog(@"moikka %@",ribale);
        
        
        
        NSArray* startAnno = [[coordinatesForFocusing objectAtIndex:0] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees longitude  = [[startAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees latitude = [[startAnno objectAtIndex:1] doubleValue];
        
        NSString *subtitle =[NSString stringWithFormat:@"%g",latitude];
        NSString *appString =[subtitle stringByAppendingFormat:@" , %g",longitude];
        NSString *secondAppString;
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        mapAnnotation *startAnnotation  = [[mapAnnotation alloc]initWithCoordinate:coordinate title:addressField.text subtitle:secondAppString endOrStart:@"leStart"];
        
        
        NSArray* endAnno = [[coordinatesForFocusing lastObject] componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        CLLocationDegrees endlongitude  = [[endAnno objectAtIndex:0] doubleValue];
        CLLocationDegrees endlatitude = [[endAnno objectAtIndex:1] doubleValue];
        
        NSString *secondSubtitle =[NSString stringWithFormat:@"%g",endlatitude];
        secondAppString =[secondSubtitle stringByAppendingFormat:@" , %g",endlongitude];
        
        CLLocationCoordinate2D endcoordinate = CLLocationCoordinate2DMake(endlatitude, endlongitude);
        mapAnnotation *endAnnotation  = [[mapAnnotation alloc]initWithCoordinate:endcoordinate title:addressFieldTo.text subtitle:appString endOrStart:@"leEnd"];
        
        //put the start and end annotations to an array and add the annotations
        endAndStartAnnotation=[NSArray arrayWithObjects:startAnnotation,endAnnotation, nil];
        [self.mapView addAnnotations:endAndStartAnnotation];
        
        //This one creates the points for the route and line from the points. Also the rectangle to zoom into.
        //    [self loadRoute];
        //zooms the map on the route
        [self zoomInOnRoute];
        
        
        
        
        //Add overlay on map with the route
        //    [self.mapView addOverlay:self.routeLine];
        
        //if there isn't array, make one
        if (!overLays) {
            overLays = [[NSMutableArray alloc]init];
        } 
        [overLays addObject:[_mapView overlays]];
    }
    
    NSLog(@"Count of the overlays: %i",_mapView.overlays.count);
    
    xmlParser = nil;
    secondcords = 0;
    legs = 0;
    elementname = nil;
    x = nil;
    y = nil;
    as = nil;
    xArray = nil;
    yArray = nil;
    putcoordstogether = nil;
    bothCoordinates = nil;
    bothCoordsTogether = nil;
    coords1 = nil;
    coords2 = nil;
    something = nil;
    _routeLineView=nil;
    walkingLines = nil;
    transports = nil;
    routesArray = nil;
    coordinatesForFocusing = nil;
    toLocationTextField.latitude = 0.0;
    toLocationTextField.longitude = 0.0;
    fromLocationTextField.longitude = 0.0;
    fromLocationTextField.latitude = 0.0;
    
    
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
 namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
   attributes:(NSDictionary *)attributeDict {
    
    
    //-------PARSING THE XML GOTTEN FROM REITTIOPAS WHEN DOING THE SEARCH--------
    if([elementName isEqualToString:@"coords"]&&(secondcords!=2)) {
        elementname = elementName;
        //        NSLog(@"my element %@",moi);
    }
    if ([elementName isEqualToString:@"coords"]&&(secondcords==2)) {
        elementname=elementName;
    }
    //--------------------------------------------------------------------------
    
    
    
    
    
    //--------PARSING THE XML TO GET THE COORDINATES FOR DRAWING THE ROUTE-------
    
    
    if ([elementName isEqualToString:@"x"]&&(boolean==YES)) {
        x=elementName;
    }
    
    if ([elementName isEqualToString:@"y"]&&(boolean==YES)) {
        y=elementName;
    }
    if ([elementName isEqualToString:@"shape"]) {
        boolean = YES;
    }
    if ([elementName isEqualToString:@"type"]) {
        booleanForTrasportType = YES;   
    }
    
    //--------------------------------------------------------------------------
    
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    //-------PARSING THE XML GOTTEN FROM REITTIOPAS WHEN DOING THE SEARCH--------
    if([elementname isEqualToString:@"coords"]&&(secondcords!=2)){
        coords1 = [[NSMutableString alloc] initWithString:string];
    }
    if ([elementname isEqualToString:@"coords"]&&(secondcords==2)) {
        coords2 = [[NSMutableString alloc] initWithString:string];
    }
    //--------------------------------------------------------------------------
    
    
    
    
    //--------PARSING THE XML TO GET THE COORDINATES FOR DRAWING THE ROUTE-------
    if (booleanForTrasportType == YES) {
        transportType = string;
        booleanForTrasportType = NO;
        
    }
    if ([x isEqualToString:@"x"]&&(legs!=1)&&(boolean==YES)) {
        if (!xArray) {
            xArray=[[NSMutableArray alloc]init];
        }
        if (!bothCoordinates) {
            bothCoordinates=[[NSMutableArray alloc]init];
        }
        if (!bothCoordsTogether) {
            bothCoordsTogether=[[NSMutableArray alloc]init];
        }
        if (!putcoordstogether) {
            putcoordstogether=[[NSMutableString alloc]init];
        }
        if (!something) {
            something=[[NSMutableString alloc]init];
        }
        [something appendString:string];
        [something appendString:@","];
        [bothCoordinates addObject:string];
        [xArray addObject:string];
        
        if ([transportType isEqualToString:@"walk"]) {
            //            [putcoordstogether appendString:@"walk"];
            //            [putcoordstogether appendString:@","];
            if (!bothCoordsTogether) {
                bothCoordsTogether=[[NSMutableArray alloc]init];
            }
            [bothCoordsTogether addObject:transportType];
            booleanForTrasportType = NO;
            transportType = nil;
            
            
        }
        if ((transportType != @"walk")&&(transportType != nil)) {
            if (!bothCoordsTogether) {
                bothCoordsTogether=[[NSMutableArray alloc]init];
            }
            NSString *asdas=@"something";
            [bothCoordsTogether addObject:asdas];
            booleanForTrasportType = NO;
            transportType = nil;
        }
        
        [putcoordstogether appendString:string];
        [putcoordstogether appendString:@","];
        
        x=nil;
    }
    
    if ([y isEqualToString:@"y"]&&(legs!=1)&&(boolean==YES)) {
        //        NSLog(@"koordiy: %@",string);
        if (!yArray) {
            yArray=[[NSMutableArray alloc]init];
        }
        [bothCoordinates addObject:string];
        [yArray addObject:string];
        [something appendString:string];
        [putcoordstogether appendString:string];
        if (!coordinatesForFocusing) {
            coordinatesForFocusing = [[NSMutableArray alloc]init];
        }
        [coordinatesForFocusing addObject:something];
        something = nil;
        
        if (!bothCoordsTogether) {
            bothCoordsTogether=[[NSMutableArray alloc]init];
        }
        [bothCoordsTogether addObject:putcoordstogether];
        putcoordstogether=nil;
        y=nil;
    }
    //--------------------------------------------------------------------------
    
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
 namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:@"shape"]) {
        boolean=NO;
    }
    if([elementName isEqualToString:@"coords"]){
        elementname=@"perkele";
        secondcords = 2;
        return;
    }
    if ([elementName isEqualToString:@"legs"]) {
        legs=1;
    }
    else{
        //         NSLog(@"Processing Value: %@", coords1);
    }
}


-(CLLocationCoordinate2D) addressLocation {
    
    double returnedLocationLat;
    double returnedLocationLong;
    //SEARCHING WITH GOOGLE MAPS 
    //from location address
    NSString *urlString1 = [NSString stringWithFormat:@"http://maps.google.com/maps/geo?q=%@&output=csv&key=ABQIAAAAaADmVtj_-nmhXjIl1g9WGRSL2BzfO-xG5dMxRVE_rQHqWh1JyBS5F3N3QoT9NYgVS7Wf1TytsQKZ_w", 
                            [addressField.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    //destination address
    NSString *urlString2 = [NSString stringWithFormat:@"http://maps.google.com/maps/geo?q=%@&output=csv&key=ABQIAAAAaADmVtj_-nmhXjIl1g9WGRSL2BzfO-xG5dMxRVE_rQHqWh1JyBS5F3N3QoT9NYgVS7Wf1TytsQKZ_w", 
                            [addressFieldTo.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]; 
    
    if ([addressField.text isEqualToString:addressFieldTo.text]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Title" message:@"Can't petform seacrch.Addresses are identical" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alert show];
    }
    else {
        
        NSURL *url =[NSURL URLWithString:urlString1];
        NSString *locationString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
        NSArray *listItems = [locationString componentsSeparatedByString:@","];
        NSLog(@"locstring1 array coords is %@",listItems);
        double locationLat1 = 0.0;
        double locationLong1 = 0.0;
        //if retrieved coordinates are correct then it returns the value 200
        if([listItems count] >= 4 && [[listItems objectAtIndex:0] isEqualToString:@"200"]){
            locationLat1 = [[listItems objectAtIndex:2] doubleValue];
            locationLong1 = [[listItems objectAtIndex:3] doubleValue];
        }
        
        NSURL *url2 =[NSURL URLWithString:urlString2];
        NSString *locationString2 = [NSString stringWithContentsOfURL:url2 encoding:NSUTF8StringEncoding error:nil];
        NSArray *listItems2 = [locationString2 componentsSeparatedByString:@","];
        NSLog(@"locstring2 array coords is %@",listItems2);
        double locationLat2 = 0.0;
        double locationLong2 = 0.0;
        //if retrieved coordinates are correct then it returns the value 200
        if([listItems2 count] >= 4 && [[listItems2 objectAtIndex:0] isEqualToString:@"200"]){
            locationLat2 = [[listItems2 objectAtIndex:2] doubleValue];
            locationLong2 = [[listItems2 objectAtIndex:3] doubleValue];
        }
        
        if (((locationLat1 >= 60.00 && locationLat1 < 60.80)&&(locationLong1 >= 23.60 && locationLong1 < 25.20)) && ((locationLat2 >= 60.00 && locationLat2 < 60.80)&&(locationLong2 >= 23.60 && locationLong2 < 25.20))){
            //only if the coordinates of the two locations entered corresponds to coordinates int the Espoo-Helsinki-Vantaa region will the shall we make a request to rettiopas's server
            
            NSString *urlString1 = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=geocode&key=%@&user=neo_ati&pass=vumi_18&format=xml&epsg_out=4326", [addressField.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            // build the string with 'to" input field
            NSString *urlString2 = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=geocode&key=%@&user=neo_ati&pass=vumi_18&format=xml&epsg_out=4326", [addressFieldTo.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
            BOOL success;
            // init and alloc nsurl with the 'from' string and get the content of it, then parse it with xml parser
            NSURL *url1 = [[NSURL alloc] initWithString:urlString1];
            xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url1];
            [xmlParser setDelegate:self];
            success=[xmlParser parse];
            
            // init and alloc nsurl with the 'to' string and get the content of it, then parse it with xml parser
            NSURL *url2 = [[NSURL alloc]initWithString:urlString2];
            xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url2];
            [xmlParser setDelegate:self];
            success=[xmlParser parse];
            
            
            
            //    NSLog(@"From coords: %@",coords1);
            //    NSLog(@"To coords: %@",coords2);
            
            NSArray *listItems1 = [coords1 componentsSeparatedByString:@","];
            NSArray *listItems2 = [coords2 componentsSeparatedByString:@","];
            coords1=nil;
            coords2=nil;
            elementname=nil;
            secondcords=0;
            
            double latitude = 0;
            double longitude = 0;
            double latitude2 = 0;
            double longitude2 = 0;
            
            if([listItems1 count] >= 2) {
                longitude = [[listItems1 objectAtIndex:0] doubleValue];
                latitude = [[listItems1 objectAtIndex:1] doubleValue];
            }
            //    NSLog(@"lati: %.10f",latitude);
            //    NSLog(@"long: %.10f",longitude);
            
            
            if([listItems2 count] >= 2) {
                longitude2 = [[listItems2 objectAtIndex:0] doubleValue];
                latitude2 = [[listItems2 objectAtIndex:1] doubleValue];
            }
            // Converting double to a string did something funny to the last decimals, limiting the number of decimals helped
            NSMutableString *latstring1 = [NSMutableString stringWithFormat:@"%g",latitude];
            NSMutableString *lonstring1 = [NSMutableString stringWithFormat:@"%g",longitude];
            
            NSMutableString *latstring2 = [NSMutableString stringWithFormat:@"%g",latitude2];
            NSMutableString *lonstring2 = [NSMutableString stringWithFormat:@"%g",longitude2];
            
            //putting together the url for route
            NSString *reitti = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=route&from=%@,%@&to=%@,%@&user=neo_ati&pass=vumi_18&detail=full&format=xml&epsg_in=4326&epsg_out=4326&show=1",[lonstring1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[latstring1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[lonstring2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[latstring2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
            NSLog(@"Reitti: %@",reitti);
            
            boolean=NO;
            
            // Get the content of url with route url and parse it with xml parser.
            NSURL *url3 = [[NSURL alloc] initWithString:reitti];
            xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url3];
            [xmlParser setDelegate:self];
            success=[xmlParser parse];
            //    NSLog(@"count of the coordinates: %i",[bothCoordsTogether count]);
            returnedLocationLat = latitude;
            returnedLocationLong = longitude;
        }
        else
        {
            fromLocationTextField.latitude = locationLat1;
            fromLocationTextField.longitude =locationLong1;
            
            toLocationTextField.latitude = locationLat2;
            toLocationTextField.longitude = locationLong2;
            //            
            //            NSLog(@"From coords lat: %g",fromLocationTextField.latitude);
            //            NSLog(@"Trom coords long : %g",fromLocationTextField.longitude);
            //            NSLog(@"To coords lat: %g",toLocationTextField.latitude);
            //            NSLog(@"To coords long: %g",toLocationTextField.longitude);
            
            
            return fromLocationTextField;
        }
        
    }
	CLLocationCoordinate2D location;
	location.latitude = returnedLocationLat;
	location.longitude = returnedLocationLat;
	[addressField resignFirstResponder];
    [addressFieldTo resignFirstResponder];
	return location;
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation{
    
    //check is the annotation start or end annotation
    if ([(mapAnnotation *)annotation endOrStart]==@"leEnd") {
        MKPinAnnotationView *annWithImg = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"end"];
        annWithImg.pinColor = MKPinAnnotationColorRed;
        annWithImg.animatesDrop = YES;
        annWithImg.canShowCallout = YES;
        annWithImg.calloutOffset = CGPointMake(-5, 1);
        
        return annWithImg;
    }
    if ([(mapAnnotation *)annotation endOrStart]==@"leStart") {
        MKPinAnnotationView *annView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"start"];
       	annView.pinColor = MKPinAnnotationColorGreen; 
        annView.animatesDrop=YES;
        annView.canShowCallout = YES;
        annView.calloutOffset = CGPointMake(-5, 5);
        
        return annView;
    }
    
    return 0;
}

-(IBAction)mapChoice:(id)sender{
    switch (((UISegmentedControl *)sender).selectedSegmentIndex) {
        case 0:
            self.mapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            self.mapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            self.mapView.mapType = MKMapTypeHybrid;
            break;
            
        default:
            break;
    }
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	
    [super didReceiveMemoryWarning];
	
	
}

- (void)viewDidUnload {
    [super viewDidUnload];
    
    
}

@end
