//
//  mapAnnotation.m
//  pushCalendar
//
//  Created by iosdev on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "mapAnnotation.h"
@implementation mapAnnotation
@synthesize coordinate;
@synthesize title;
@synthesize endOrStart;
@synthesize subtitle;


-(id)initWithCoordinate:(CLLocationCoordinate2D) c
                  title:(NSString *)aTitle
               subtitle:(NSString *)sTitle
             endOrStart:(NSString *)endorstart{
	coordinate=c;
    subtitle=sTitle;
    title = aTitle;
    endOrStart = endorstart;
	//NSLog(@"%f,%f",c.latitude,c.longitude);
	return self;
}

@end
