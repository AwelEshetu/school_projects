//
//  LogIn.h
//  pushCalendar
//
//  Created by iosdev on 12/7/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "userView.h"

@class userView;
@interface LogIn : UIViewController
{
    IBOutlet UITextField *email;
    IBOutlet UITextField *password;
    IBOutlet userView *userview;
    UILabel *status;
    NSString *token;
    NSString *newToken;
    NSInteger *test;
    NSString *conIntValue;
    

}

@property (nonatomic ,strong) UITextField *email; 
@property (nonatomic ,strong) UITextField *password; 
@property(nonatomic, strong) IBOutlet UILabel *status;


-(IBAction)login;
-(IBAction)createUser;
-(void)deleteAllObjects;

@end
