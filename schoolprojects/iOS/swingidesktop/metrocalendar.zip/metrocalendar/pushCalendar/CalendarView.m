//
//  CalendarView.m
//  IphoneCalendar
//
//  Created by iosdev on 11/10/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CalendarView.h"
#import <QuartzCore/QuartzCore.h>
#import "AddEvent.h"
#import "AppDelegate.h"
#import "DetailViewController.h"


const unsigned int uppermargin =80;

const float width=40;
const  float height=35;
const  float prevNextButtonSize=20;
const  float prevNextButtonSpaceWidth=15;
const float prevNextButtonSpaceHeight=10;

@implementation CalendarView

@synthesize currentTime;
@synthesize currentMonthDate;
@synthesize currentSelectDate;
@synthesize viewImageView;
@synthesize currentWeek ;
@synthesize Date;
@synthesize coreDataEvent;





-(void)initCalView{
	currentTime=CFAbsoluteTimeGetCurrent();
	currentMonthDate=CFAbsoluteTimeGetGregorianDate(currentTime,CFTimeZoneCopyDefault());
	currentMonthDate.day=1;
	currentSelectDate.year=0;
    currentWeek = CFAbsoluteTimeGetGregorianDate(currentTime, CFTimeZoneCopyDefault());
    [self getWeekOfYear:currentWeek];
    self.backgroundColor=[UIColor whiteColor];
    
    
    
}

- (id)initWithCoder:(NSCoder *)coder {
    if (self = [super initWithCoder:coder]) {
		[self initCalView];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
	
	if (self = [super initWithFrame:frame]) {
		[self initCalView];
	}
	return self;
}

#pragma mark -
#pragma mark function to get total days of the current month
-(int)getDayCountOfaMonth:(CFGregorianDate)date{
	switch (date.month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
			
		case 2:
			if(date.year%4==0 && date.year%100!=0)
				return 29;
			else
				return 28;
		case 4:
		case 6:
		case 9:		
		case 11:
			return 30;
		default:
			return 31;
	}
}

#pragma mark Draw

-(void)drawPrevButton:(CGPoint)leftTop{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetGrayStrokeColor(ctx, 0, 1);
    CGContextMoveToPoint(ctx,leftTop.x , prevNextButtonSpaceWidth/2+leftTop.y);
    CGContextAddLineToPoint(ctx, prevNextButtonSize+leftTop.x, leftTop.y);
    CGContextAddLineToPoint(ctx, prevNextButtonSize+leftTop.x, prevNextButtonSize+leftTop.y);
    //CGContextAddLineToPoint(ctx, 0+leftTop.x, 0+leftTop.y);
    
    CGContextFillPath(ctx);
}


-(void)drawNextButton:(CGPoint )leftTop{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetGrayStrokeColor(ctx, 0, 1);
    CGContextMoveToPoint(ctx,leftTop.x,  leftTop.y);
    CGContextAddLineToPoint(ctx, prevNextButtonSize+leftTop.x, prevNextButtonSpaceHeight+leftTop.y);
    CGContextAddLineToPoint(ctx, 0+leftTop.x, prevNextButtonSize+leftTop.y);
    // CGContextAddLineToPoint(ctx, 0+leftTop.x, 0+leftTop.y);
    
    CGContextFillPath(ctx);
    
}

-(void)drawTopGradientBar{
    
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    size_t num_locations=3;
    CGFloat locations[3]={0.0,0.3,1.0};                     // total number of position
    CGFloat components[12]={0.2,0.2,0.2,1.0,
        0.66,0.66,0.66,1.0,
        0.10,0.10,0.10,1.0
    };                                                      // color combination
    CGGradientRef myGradient;
    CGColorSpaceRef myColorspace = CGColorSpaceCreateDeviceRGB();
    myGradient =CGGradientCreateWithColorComponents(myColorspace, components, locations, num_locations);
    CGPoint myStartPoint, myEndPoint;
    myStartPoint.x=uppermargin;
    myStartPoint.y=0.0;
    myEndPoint.x=uppermargin;
    myEndPoint.y=uppermargin;
    CGContextDrawLinearGradient(ctx, myGradient, myStartPoint, myEndPoint, 0);
    
    //------Release the Gradient and colorspace
    CGGradientRelease(myGradient);
    CGColorSpaceRelease(myColorspace);
    
    [self drawPrevButton:CGPointMake(10, 15)];
    [self drawNextButton:CGPointMake(290, 15)];
    
    
    
}


- (void)drawDateBoxes {
    
    int x,y;
    CGRect rectangle;
    // Drawing code
    for(int i =0;i<6;i++){
        y=i*height+uppermargin;
        
        for(int j =0;j<8;j++){
            x=j*width;
            
            CGMutablePathRef path = CGPathCreateMutable();              /*create the path first*/
            rectangle = CGRectMake(x, y, width, height);  /*our rectangle boundaries*/
            CGPathAddRect(path, NULL, rectangle);                       /*add the rectangle to the path*/
            CGContextRef currentContext =UIGraphicsGetCurrentContext(); /*get the handle to the current context*/
            CGContextAddPath(currentContext, path);                       /*add the path to the context*/
            [[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f]setFill];/*set the fill color*/
            [[UIColor colorWithRed:0.0f green:0.0f blue:0.10f alpha:0.1f]setStroke];                            //set the stroke color to brown
            CGContextSetLineWidth(currentContext, 1.0f);                                    /*set the line width*/
            CGContextDrawPath(currentContext, kCGPathFillStroke);       /*stroke and fill the path on the context*/
            CGPathRelease(path);  
            
        }/*dispose of the path*/
    }
    
    
}

#pragma mark -
#pragma mark function to draw Month Name at top

-(void)drawNameOfDaysAtTop {
    
    [[UIColor whiteColor]set];
    int width = self.frame.size.width;// gives the total size of the frame ie 320
    int s_width = width/8;// we want to have the display in the same amount of distance 8 column
    int fontsize= [UIFont buttonFontSize]; //buttonFontSize returns the fonts suitable for a button
    NSString *monthName;
    int counter;
    switch (currentMonthDate.month) {
        case 1:
            monthName=@"January";
            counter = [monthName length];
            break;
        case 2:
            monthName=@"February";
            counter = [monthName length];
            break;
        case 3:
            monthName=@"March";
            counter = [monthName length];
            break;
        case 4:
            monthName=@"April";
            counter = [monthName length];
            break;
        case 5:
            monthName=@"May";
            counter = [monthName length];
            break;
        case 6:
            monthName=@"June";
            counter = [monthName length];
            break;
        case 7:
            monthName=@"July";
            counter = [monthName length];
            break;
        case 8:
            monthName=@"August";
            counter = [monthName length];
            break;
        case 9:
            monthName=@"September";
            counter = [monthName length];
            break;
        case 10:
            monthName=@"October";
            counter = [monthName length];
            break;
        case 11:
            monthName=@"November";
            counter = [monthName length];
            break;
        case 12:
            monthName=@"December";
            counter = [monthName length];
            break;
            
        default:
            break;
    }
    
    NSString *title_Month = [[NSString alloc]initWithFormat:@"%@ %d",monthName,currentMonthDate.year];
    UIFont *font = [UIFont boldSystemFontOfSize:24];
    CGPoint location = CGPointMake( (width/2 -((counter+5)*11.5)/2), prevNextButtonSpaceHeight); //location holds the points set by cgpointmake
    
    [title_Month drawAtPoint:location withFont:font];    
    UIFont *weekfont = [UIFont boldSystemFontOfSize:15];
    
    fontsize+=30;
    
    [[UIColor orangeColor]set];
    [@"Wk" drawAtPoint:CGPointMake(s_width*0+9,fontsize) withFont:weekfont];
    [[UIColor whiteColor]set];
    [@"Mon" drawAtPoint:CGPointMake(s_width*0.89+9,fontsize) withFont:weekfont];
    [@"Tue" drawAtPoint:CGPointMake(s_width*1.89+9,fontsize) withFont:weekfont];
	[@"Wed" drawAtPoint:CGPointMake(s_width*2.89+9,fontsize) withFont:weekfont];
	[@"Thu" drawAtPoint:CGPointMake(s_width*3.89+9,fontsize) withFont:weekfont];
	[@"Fri" drawAtPoint:CGPointMake(s_width*4.89+9,fontsize) withFont:weekfont];
	[[UIColor colorWithRed:2.0 green:2.0 blue:2.0 alpha:0.9]set];
	[@"Sat" drawAtPoint:CGPointMake(s_width*5.89+9,fontsize) withFont:weekfont];
    [[UIColor redColor] set];
	[@"Sun" drawAtPoint:CGPointMake(s_width*6.8+9,fontsize) withFont:weekfont];
    [[UIColor blackColor]set];
    
    
}



#pragma mark -
#pragma mark function to get the first day of the month

- (int)getMonthWeekday:(CFGregorianDate)date{
    
    CFTimeZoneRef timezone= CFTimeZoneCopyDefault();
    CFGregorianDate month_date;
    month_date.year = date.year;
    month_date.month=date.month;
    month_date.day=1;
    month_date.hour=0;
    month_date.minute=0;
    month_date.second=1;      
    
    return (int)CFAbsoluteTimeGetDayOfWeek(CFGregorianDateGetAbsoluteTime(month_date, timezone), timezone);//2
    
}

#pragma mark -
#pragma mark function to get the current week of the month
-(int)getWeekOfYear:(CFGregorianDate)date{
    
    CFTimeZoneRef timezone= CFTimeZoneCopyDefault();
    CFGregorianDate month_date;
    month_date.year = date.year;
    month_date.month=date.month;
    month_date.day=date.day;
    month_date.hour=0;
    month_date.minute=0;
    month_date.second=1;
    
    return (int)CFAbsoluteTimeGetWeekOfYear(CFGregorianDateGetAbsoluteTime(month_date, timezone), timezone);
}

#pragma mark -
#pragma mark function to draw dates of the month

-(void)drawDateWords{
    
    CGContextRef ctx =UIGraphicsGetCurrentContext();
    int width = self.frame.size.width;
    
    int dayCount = [self getDayCountOfaMonth:currentMonthDate];
    int day =0;
    int x =0;
    int y =0,i;
    int s_width=width/8;
    int check_saturday=0;
    int check_week=90;
    
    int current_weekday = [self getMonthWeekday:currentMonthDate];  
    int getweekofthemonth = [self getWeekOfYear:currentMonthDate];
    NSLog(@"current week = %d",getweekofthemonth);
    
    
    /*if current month is January but first day is still part of week 52, the system gives week 53 for that day, in that case change it to 52*/
    //added by Udeep to check if the year starts with week 53 or 52
    int week53isTrue = 0; // a flag to check whether year starts with week 53
    
    if(getweekofthemonth >52){
        CFGregorianDate prevmonthslastday;
        prevmonthslastday.year = currentMonthDate.year-1;
        prevmonthslastday.month=12;
        prevmonthslastday.day=31;
        int prevmonthslastdayweek = [self getWeekOfYear:prevmonthslastday];
        
        if(prevmonthslastdayweek!=53){
            getweekofthemonth =52;           
        }
        else{
            week53isTrue =1;
        }
        
    } 
    // codes to check if the year starts with week 53 or 52  ends here
    
    
    //-------- Draw Week Numbers ----------------
    
    UIFont *weekfont =[UIFont boldSystemFontOfSize:15];        
    [[UIColor orangeColor]set];
    
    for(int k =1;k<7;k++){
        
        if(getweekofthemonth >52&&week53isTrue==0){
            CFGregorianDate monthslastday;
            monthslastday.year = currentMonthDate.year;
            monthslastday.month=currentMonthDate.month;
            monthslastday.day=31;
            
            int lastWeekNumber=[self getWeekOfYear:monthslastday];
            if(lastWeekNumber != 53){
                getweekofthemonth =1;}
            
        }
        if(getweekofthemonth >53){
            getweekofthemonth =1;}
        
        NSString *week = [[NSString alloc]initWithFormat:@"%2d",getweekofthemonth];   
        [week drawAtPoint:CGPointMake(s_width-30, check_week) withFont:weekfont];
        getweekofthemonth++;
        check_week+=35;
        
    }
    
    
    [[UIColor blackColor]set];       
    for( i=1;i<dayCount+1;i++){
        day = i + current_weekday-2;  
        x = day%7;
        y=day/7;
        
        
        //printing 
        NSString *date = [[NSString alloc]initWithFormat:@"%2d",i];
        
        // Saturday and Sunday for colouring
        check_saturday=x*s_width+50;
        
        //--------- Draw the previous month days in front of empty cells-------------------------------
        if(i==1){
            CFGregorianDate prevMonthDate = CFAbsoluteTimeGetGregorianDate(currentTime, CFTimeZoneCopySystem());
            
            prevMonthDate.year=currentMonthDate.year;
            prevMonthDate.month= currentMonthDate.month-1;
            
            int prevmonthdayCount = [self getDayCountOfaMonth:prevMonthDate];
            int pos;
            int beginning=check_saturday-s_width;
            [[UIColor grayColor]set];
            for(pos=beginning;pos>=50;pos-=s_width){
                NSString *prevdate = [[NSString alloc]initWithFormat:@"%2d",prevmonthdayCount];
                [prevdate drawAtPoint:CGPointMake(pos, uppermargin+10) withFont:weekfont];
                prevmonthdayCount--;
                
            }
            [[UIColor blackColor]set];    
            
        }
        
        
        //colour saturday
        if(check_saturday ==250){
            [[UIColor blackColor]set];
            [date drawAtPoint:CGPointMake(x*s_width+50, y*35+uppermargin+10) withFont:weekfont];
            
        }
        
        //colour sunday
        else if(check_saturday == 290){
            [[UIColor redColor]set];
            [date drawAtPoint:CGPointMake(x*s_width+50, y*35+uppermargin+10) withFont:weekfont];
            
        }
        else{
            [date drawAtPoint:CGPointMake(x*s_width+50, y*35+uppermargin+10) withFont:weekfont];
            
        }
        
        CGContextSetRGBFillColor(ctx, 0, 0, 0, 1);
    }
    // -----------------------printing next month's dates ----------------
    int nextdate=1;
    int endx=(x+1)*s_width+50;
    [[UIColor grayColor]set];
    for(int endy=y*35+uppermargin+10;endy<=5*35+uppermargin+10;endy+=35){
        for(;endx<=6*s_width+50;endx+=s_width){
            NSString *nextdatestring = [[NSString alloc]initWithFormat:@"%2d",nextdate];
            [nextdatestring drawAtPoint:CGPointMake(endx, endy) withFont:weekfont];
            nextdate++;
            
        }
        endx=0*s_width+50;
        
    }
    //printing next month's dates ends here
    
}

// Display the view whenever the arrow is tapped
-(void)movePrevNext:(int)isPrev{
    
    currentSelectDate.year =0;
    
    
    int width=self.frame.size.width;
    int position;
    if(isPrev==1){
        position=width;
    }
    else
        position=-width;
    
    UIImage *viewImage;
    
    UIGraphicsBeginImageContext(self.bounds.size);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
    viewImage = UIGraphicsGetImageFromCurrentImageContext();
    if(viewImageView ==nil){
        viewImageView = [[UIImageView alloc]initWithImage:viewImage];
        viewImageView.center=self.center;
        [[self superview]  addSubview:viewImageView];
        
    }
    else
    {
        viewImageView.image=viewImage;
        
    }
    
    // viewImageView.hidden =NO;
    viewImageView.transform = CGAffineTransformMakeTranslation(0, 0);
    self.hidden=YES;
    [self setNeedsDisplay];
    self.transform=CGAffineTransformMakeTranslation(position, 0);
    
    
    self.hidden=NO;
	[UIView beginAnimations:nil	context:nil];
	[UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    
	self.transform=CGAffineTransformMakeTranslation(0,0);
	viewImageView.transform=CGAffineTransformMakeTranslation(-position, 0);
     //[UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:viewImageView cache:YES];
    
	[UIView commitAnimations];
    
    
    
}
//---------function to get the month and week for next month---------------- 
- (void)movePrevMonth{
    // int decrease=12;
	if(currentMonthDate.month>1){
		currentMonthDate.month-=1;
        
        //[self getWeekOfYear:currentMonthDate];
        
        // NSLog(@"check the WeekHere1 %d",collectWeekNumbers);
    }
	else
	{
		currentMonthDate.month=12;
		currentMonthDate.year-=1;
        
	}
	[self movePrevNext:0]; 
    //[self getWeekOfYear:currentMonthDate ];
    
    
}

//-------------function to get the month and week for previous month ------------------
- (void)moveNextMonth{
	if(currentMonthDate.month<12){
		currentMonthDate.month+=1;
        
        
    }
	else
	{
		currentMonthDate.month=1;
		currentMonthDate.year+=1;
        
	}
	[self movePrevNext:1];
    [self getWeekOfYear:currentMonthDate];
	
    
}


#pragma mark -
#pragma mark function to draw dates of the month
-(void) drawToday{
    
    int x;
    int y;
    int day;
    CFGregorianDate today = CFAbsoluteTimeGetGregorianDate(currentTime, CFTimeZoneCopySystem());
    if(today.month == currentMonthDate.month && today.year==currentMonthDate.year){
        
        int width = self.frame.size.width;
        int s_width=width/8;
        int weekday = [self getMonthWeekday:currentMonthDate];
        day=today.day+weekday-2;
        x=day%7;
        y=day/7;
        
        CGContextRef ctx = UIGraphicsGetCurrentContext();
        
        
        //to shade the cell for today's date
	 	CGContextSetRGBFillColor(ctx, 0.1, 0.1, 0.4, 0.4);
		CGContextMoveToPoint(ctx, x*s_width+40, y*35+80);
		CGContextAddLineToPoint(ctx, x*s_width+s_width+40, y*35+80);
		CGContextAddLineToPoint(ctx, x*s_width+s_width+40, y*35+115);
		CGContextAddLineToPoint(ctx, x*s_width+40, y*35+115);
		CGContextFillPath(ctx); 
        
        
        CGContextSetRGBFillColor(ctx, 0, 1, 1, 1);
        UIFont *weekfont = [UIFont boldSystemFontOfSize:15];
        NSString *date = [[NSString alloc]initWithFormat:@"%2d",today.day];
        
        [date drawAtPoint:CGPointMake(x*s_width+50, y*35+90) withFont:weekfont];
        
    }
    
}
-(void)HasAnyEvent {
    
    
    int x;
    int y;
    int day;
    int height =35;
    int uppermargin =80;
    int s_width=40;
    int weekday = [self getMonthWeekday:currentMonthDate];
    int monthDayCount=[self getDayCountOfaMonth:currentMonthDate];
    NSString *mitti;
    BOOL checkflag;
    
    //Core Data Begins
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSManagedObjectContext *context = [appDelegate managedObjectContext];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:context];
    NSFetchRequest *request = [[NSFetchRequest alloc]init];
    [request setEntity:entityDesc];
    
    NSError *error;
    NSManagedObject *matches = nil;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    
    NSInteger countMatchObject=[objects count];
    int counter=0;
    NSMutableArray *collectDate = [[NSMutableArray alloc]init];
    
    while (countMatchObject!=0) {
        matches = [objects objectAtIndex:counter];
        counter++;
        NSString *dateString=[matches valueForKey:@"date"];
        
        countMatchObject--;
        
        NSLog(@"my object %@",dateString );
        
      [collectDate addObject:dateString];
        
    }
    
    // NSLog(@"collected Date %@",collectDate);
    int dateCountsFromserver= [collectDate count];
    // core Data Ends
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    for(int i=1;i< monthDayCount+1;i++){
        day=i+weekday-2;
        
        x=day%7;
        y=day/7;
        
        // NSString *mitti = [NSString stringWithFormat:@"%d-%d-%d",currentMonthDate.year,currentMonthDate.month,i];
        int placeZero=0;
        if(i <10)
            mitti = [NSString stringWithFormat:@"%d-%d-%d%d",currentMonthDate.year,currentMonthDate.month,placeZero,i];
        else
            mitti = [NSString stringWithFormat:@"%d-%d-%d",currentMonthDate.year,currentMonthDate.month,i];
        
        checkflag = YES;
        for (int checktime = dateCountsFromserver-1; checktime>=0;checktime--) {
            
            if ([mitti isEqualToString:[collectDate objectAtIndex:checktime]]) {
                
                if(checkflag==YES){
                    CGContextSetRGBFillColor(ctx, 0.0, 0.6, 0.2, 0.4);
                    CGContextMoveToPoint(ctx,  x*s_width+s_width+s_width,  y*height+uppermargin+15);
                    CGContextAddLineToPoint(ctx,  x*s_width+s_width+s_width ,  y*height+uppermargin+15);
                    CGContextAddLineToPoint(ctx,  x*s_width+s_width+33.3,  y*height+uppermargin+height);
                    CGContextAddLineToPoint(ctx,  x*s_width+s_width+s_width,  y*height+uppermargin+height);
                    CGContextFillPath(ctx); 
                    checkflag = NO;   
                }
                
            }
        }
    }
    
    
    
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    currentTime = CFAbsoluteTimeGetCurrent();
    [self drawTopGradientBar]; 
    
    [self drawNameOfDaysAtTop];
    [self drawDateBoxes];
    [self drawDateWords];
    [self drawToday];
    [self HasAnyEvent];
    
    
}







@end
