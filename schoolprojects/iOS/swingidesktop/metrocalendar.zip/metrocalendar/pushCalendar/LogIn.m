//
//  LogIn.m
//  pushCalendar
//
//  Created by iosdev on 12/7/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "LogIn.h"
#import "AppDelegate.h"

@implementation LogIn

@synthesize email;
@synthesize password;
@synthesize status;

- (void) deleteAllObjects{
    
    AppDelegate *appDelegate2 =(AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *context2 = [appDelegate2 managedObjectContext];
    //NSManagedObjectModel *log_in;
    //log_in = [NSEntityDescription insertNewObjectForEntityForName:@"Event" inManagedObjectContext:context2];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:context2];
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSArray *items = [context2 executeFetchRequest:fetchRequest error:&error];
    for (NSManagedObject *managedObject in items) {
        [context2 deleteObject:managedObject];
        NSLog(@"object deleted");
    }
    if (![context2 save:&error]) {
        NSLog(@"Error deleting - error:%@",error);
    }
    
}
-(IBAction)login
{
    
    
    
    NSError *error;
    NSLog(@"token from core: %@", token);
    
    if ([email.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"Email cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    }
    else if([password.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"password cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    
        
    }
    
    else
    {
        NSString *urlString = [NSString stringWithFormat:@"http://ec2-204-236-207-173.compute-1.amazonaws.com/test/log_in.php?email=%@&password=%@",email.text, password.text];
        
        NSLog(@"the urlstring: %@",urlString);
        
        NSURL *url = [[NSURL alloc] initWithString:urlString];
        
        NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
        
        //NSData *urlData;
        NSURLResponse *response;
        
        
        
        NSString *responseData= [[NSString alloc] initWithData:[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error] encoding:NSUTF8StringEncoding]; 
        
        NSLog(@"server response is %@\n", responseData);
        
        NSMutableString *strippedString = [NSMutableString 
                                           stringWithCapacity:responseData.length];
        NSScanner *scr = [[NSScanner alloc] initWithString:responseData];
        
        NSCharacterSet *numbers = [NSCharacterSet 
                                   characterSetWithCharactersInString:@"0123456789"];
        
        while ([scr isAtEnd] == NO) {
            NSString *buffer;
            if ([scr scanCharactersFromSet:numbers intoString:&buffer]) {
                [strippedString appendString:buffer];
                
            } else {
                [scr setScanLocation:([scr scanLocation] + 1)];
            }
        }
        
        NSLog(@"%@", strippedString);
        
        NSNumber *num = [NSNumber numberWithInteger: [strippedString integerValue]];
        NSLog(@"num is %@", num);
        int con;
        con = [num intValue];
       // NSLog(@"con is %@",con);
        
        if (con == 1)
        {
            UIAlertView *alert =
            [[UIAlertView alloc] initWithTitle:@"Error"
                                       message:@"User name not found."
                                      delegate:nil
                             cancelButtonTitle:nil
                             otherButtonTitles:@"OK", nil];
            [alert show]; 
            email.text = nil;
            password.text = nil;


        }
        else if(con > 1)
        {
            
            AppDelegate *appDelegate1 =(AppDelegate *)[[UIApplication sharedApplication] delegate];
            NSManagedObjectContext *context1 = [appDelegate1 managedObjectContext];
            NSManagedObjectModel *log_in;
            log_in = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:context1];
            [log_in setValue:email.text forKey:@"email"];
            [log_in setValue:num forKey:@"userID"];
            [log_in setValue:token forKey:@"token"];
            
            [self deleteAllObjects];
            [context1 save:&error];
            UIAlertView *alert =
            [[UIAlertView alloc] initWithTitle:@""
                                       message:@"Login Successful."
                                      delegate:nil
                             cancelButtonTitle:nil
                             otherButtonTitles:@"OK", nil];
            [alert show]; 
            email.text = nil;
            password.text = nil;
            
            newToken = [token description];
            newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
            newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];  // change the token to hexadecimal            string.
            NSLog(@"new token is %@", newToken);
            
            NSString *urlString = [NSString stringWithFormat:@"http://ec2-204-236-207-173.compute-1.amazonaws.com/test/gettoken.php?newToken=%@&user_id=%d",newToken,con];
            
            
            NSLog(@"my token in urlstring: %@",urlString);
            NSURL *url = [[NSURL alloc] initWithString:urlString];
            
            NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
            
            //NSData *urlData;
            NSURLResponse *response;
            NSError *error;
            //urlData = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error];
            
            NSString *responseData= [[NSString alloc] initWithData:[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error] encoding:NSUTF8StringEncoding]; 
            
            
            //NSLog(@"error is %@\n", error);
            //NSLog(@"url data: %@\n",urlData );
            NSLog(@"server response is %@\n", responseData);
            
            

            
            
            
        }
        else if (con == 0)
        {
            UIAlertView *alert =
            [[UIAlertView alloc] initWithTitle:@"Error"
                                       message:@"Wrong password."
                                      delegate:nil
                             cancelButtonTitle:nil
                             otherButtonTitles:@"OK", nil];
            [alert show];    
            [status setText:@"Wrong Password"];
            password.text = nil;
        }
        
    }
    
       
    
   
}
-(IBAction)createUser
{
    userview.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    userView *createUser = [[userView alloc] init];
    [self presentModalViewController:createUser animated:YES];
    
}


-(IBAction)removeKeyboard:(id)sender{
    
    [email resignFirstResponder];
    
}

    

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Log In", @"Log In");
        
        self.tabBarItem.image = [UIImage imageNamed:@"111-user"];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [password setSecureTextEntry:YES];
    
    AppDelegate  *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSFetchRequest *UserRequest = [[NSFetchRequest alloc] init];
    NSManagedObjectContext *Context = [appDelegate managedObjectContext];
    NSEntityDescription *EntityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:[appDelegate managedObjectContext]];
    UserRequest = [[NSFetchRequest alloc]init];
    [UserRequest setEntity:EntityDesc];
    
    NSError *error1;
    NSManagedObject *matches1 = nil;
    NSArray *objects1 = [Context executeFetchRequest:UserRequest error:&error1];
    
    NSInteger countMatchObject1=[objects1 count];
    int counter1=0;
    
    
    while (countMatchObject1!=0) {
        matches1 = [objects1 objectAtIndex:counter1];
        counter1++;
        token=[matches1 valueForKey:@"token"];
        NSLog(@"token from core is: %@",token);
        
        countMatchObject1--;
        
        
    }   

    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
