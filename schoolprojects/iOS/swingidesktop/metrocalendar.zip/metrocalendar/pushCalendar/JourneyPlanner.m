//
//  JourneyPlanner.m
//  pushCalendar
//
//  Created by iosdev on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "JourneyPlanner.h"
#import "MapView.h"

@implementation JourneyPlanner
@synthesize table;
@synthesize selectedRow;
@synthesize bothCoordsTogether,bothCoordsTogether2,bothCoordsTogether3;
@synthesize coordinatesForFocusing,coordinatesForFocusing2,coordinatesForFocusing3;

-(IBAction)back
{
    [self.parentViewController dismissModalViewControllerAnimated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict{
    
    //-------PARSING THE XML GOTTEN FROM REITTIOPAS WHEN DOING THE SEARCH--------
    if([elementName isEqualToString:@"coords"]&&(secondcords!=2)) {
        elementname = elementName;
        //        NSLog(@"my element %@",moi);
    }
    if ([elementName isEqualToString:@"coords"]&&(secondcords==2)) {
        elementname=elementName;
    }
    //--------------------------------------------------------------------------
    
    
    if ([elementName isEqualToString:@"legs"]) {
        elementname=elementName;
    }
    
    if ([elementname isEqualToString:@"legs"]&&[elementName isEqualToString:@"type"]) {
        types=elementName;
    }
    if ([elementName isEqualToString:@"shape"]) {
        shapeBool = YES;
    }
    if ([elementName isEqualToString:@"x"]&&(shapeBool==YES)) {
        x=elementName;
    }
    
    if ([elementName isEqualToString:@"y"]&&(shapeBool==YES)) {
        y=elementName;
    }
    if ([elementName isEqualToString:@"type"]) {
        booleanForTrasportType = YES;   
    }
    
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    //-------PARSING THE XML GOTTEN FROM REITTIOPAS WHEN DOING THE SEARCH--------
    if([elementname isEqualToString:@"coords"]&&(secondcords!=2)){
        coords1 = [[NSMutableString alloc] initWithString:string];
    }
    if ([elementname isEqualToString:@"coords"]&&(secondcords==2)) {
        coords2 = [[NSMutableString alloc] initWithString:string];
    }
    //--------------------------------------------------------------------------
    
    
    if ([types isEqualToString:@"type"]&&(intForRoutes==1)) {
        if (!firstRoute) {
            firstRoute = [[NSMutableArray alloc]init];
        }
        [firstRoute addObject:string];
    }
    if ([types isEqualToString:@"type"]&&(intForRoutes==2)) {
        if (!secondRoute) {
            secondRoute = [[NSMutableArray alloc]init];
        }
        [secondRoute addObject:string];
    }
    if ([types isEqualToString:@"type"]&&(intForRoutes==3)) {
        if (!thirdRoute) {
            thirdRoute = [[NSMutableArray alloc]init];
        }
        [thirdRoute addObject:string];
    }
    
    if (booleanForTrasportType == YES) {
        transportType = string;
        booleanForTrasportType = NO;
        
    }
    
    if ((intForRoutes==1) && (shapeBool==YES)) {

        if ([x isEqualToString:@"x"]) {
            if (!xArray) {
                xArray=[[NSMutableArray alloc]init];
            }
            if (!bothCoordinates) {
                bothCoordinates=[[NSMutableArray alloc]init];
            }
            if (!self.bothCoordsTogether) {
                self.bothCoordsTogether=[[NSMutableArray alloc]init];
            }
            if (!putcoordstogether) {
                putcoordstogether=[[NSMutableString alloc]init];
            }
            if (!something) {
                something=[[NSMutableString alloc]init];
            }
            [something appendString:string];
            [something appendString:@","];
            [bothCoordinates addObject:string];
            [xArray addObject:string];
            
            if ([transportType isEqualToString:@"walk"]) {
                //            [putcoordstogether appendString:@"walk"];
                //            [putcoordstogether appendString:@","];
                if (!self.bothCoordsTogether) {
                    self.bothCoordsTogether=[[NSMutableArray alloc]init];
                }
                [self.bothCoordsTogether addObject:transportType];
                booleanForTrasportType = NO;
                transportType = nil;
                
                
            }
            if ((transportType != @"walk")&&(transportType != nil)) {
                if (!self.bothCoordsTogether) {
                    self.bothCoordsTogether=[[NSMutableArray alloc]init];
                }
                NSString *asdas=@"something";
                [self.bothCoordsTogether addObject:asdas];
                booleanForTrasportType = NO;
                transportType = nil;
            }
            
            [putcoordstogether appendString:string];
            [putcoordstogether appendString:@","];
            
            x=nil;
        }
        if ([y isEqualToString:@"y"]) {
            //        NSLog(@"koordiy: %@",string);
            if (!yArray) {
                yArray=[[NSMutableArray alloc]init];
            }
            [bothCoordinates addObject:string];
            [yArray addObject:string];
            [something appendString:string];
            [putcoordstogether appendString:string];
            if (!coordinatesForFocusing) {
                coordinatesForFocusing = [[NSMutableArray alloc]init];
            }
            [coordinatesForFocusing addObject:something];
            something = nil;
            
            if (!self.bothCoordsTogether) {
                self.bothCoordsTogether=[[NSMutableArray alloc]init];
            }
            [self.bothCoordsTogether addObject:putcoordstogether];
            putcoordstogether=nil;
            y=nil;
        }
        
    }
    
    if (intForRoutes==2 && shapeBool==YES) {
        
        if ([x isEqualToString:@"x"]) {
            if (!xArray) {
                xArray=[[NSMutableArray alloc]init];
            }
            if (!bothCoordinates) {
                bothCoordinates=[[NSMutableArray alloc]init];
            }
            if (!bothCoordsTogether2) {
                bothCoordsTogether2=[[NSMutableArray alloc]init];
            }
            if (!putcoordstogether) {
                putcoordstogether=[[NSMutableString alloc]init];
            }
            if (!something) {
                something=[[NSMutableString alloc]init];
            }
            [something appendString:string];
            [something appendString:@","];
            [bothCoordinates addObject:string];
            [xArray addObject:string];
            
            if ([transportType isEqualToString:@"walk"]) {
                //            [putcoordstogether appendString:@"walk"];
                //            [putcoordstogether appendString:@","];
                if (!bothCoordsTogether2) {
                    bothCoordsTogether2=[[NSMutableArray alloc]init];
                }
                [bothCoordsTogether2 addObject:transportType];
                booleanForTrasportType = NO;
                transportType = nil;
                
                
            }
            if ((transportType != @"walk")&&(transportType != nil)) {
                if (!bothCoordsTogether2) {
                    bothCoordsTogether2=[[NSMutableArray alloc]init];
                }
                NSString *asdas=@"something";
                [bothCoordsTogether2 addObject:asdas];
                booleanForTrasportType = NO;
                transportType = nil;
            }
            
            [putcoordstogether appendString:string];
            [putcoordstogether appendString:@","];
            
            x=nil;
        }
        if ([y isEqualToString:@"y"]) {
            //        NSLog(@"koordiy: %@",string);
            if (!yArray) {
                yArray=[[NSMutableArray alloc]init];
            }
            [bothCoordinates addObject:string];
            [yArray addObject:string];
            [something appendString:string];
            [putcoordstogether appendString:string];
            if (!coordinatesForFocusing2) {
                coordinatesForFocusing2 = [[NSMutableArray alloc]init];
            }
            [coordinatesForFocusing2 addObject:something];
            something = nil;
            
            if (!bothCoordsTogether2) {
                bothCoordsTogether2=[[NSMutableArray alloc]init];
            }
            [bothCoordsTogether2 addObject:putcoordstogether];
            putcoordstogether=nil;
            y=nil;
        }
    }
    
    if (intForRoutes==3 && shapeBool==YES) {
        
        if ([x isEqualToString:@"x"]) {
            if (!xArray) {
                xArray=[[NSMutableArray alloc]init];
            }
            if (!bothCoordinates) {
                bothCoordinates=[[NSMutableArray alloc]init];
            }
            if (!bothCoordsTogether3) {
                bothCoordsTogether3=[[NSMutableArray alloc]init];
            }
            if (!putcoordstogether) {
                putcoordstogether=[[NSMutableString alloc]init];
            }
            if (!something) {
                something=[[NSMutableString alloc]init];
            }
            [something appendString:string];
            [something appendString:@","];
            [bothCoordinates addObject:string];
            [xArray addObject:string];
            
            if ([transportType isEqualToString:@"walk"]) {
                //            [putcoordstogether appendString:@"walk"];
                //            [putcoordstogether appendString:@","];
                if (!bothCoordsTogether3) {
                    bothCoordsTogether3=[[NSMutableArray alloc]init];
                }
                [bothCoordsTogether3 addObject:transportType];
                booleanForTrasportType = NO;
                transportType = nil;
                
                
            }
            if ((transportType != @"walk")&&(transportType != nil)) {
                if (!bothCoordsTogether3) {
                    bothCoordsTogether3=[[NSMutableArray alloc]init];
                }
                NSString *asdas=@"something";
                [bothCoordsTogether3 addObject:asdas];
                booleanForTrasportType = NO;
                transportType = nil;
            }
            
            [putcoordstogether appendString:string];
            [putcoordstogether appendString:@","];
            
            x=nil;
        }
        if ([y isEqualToString:@"y"]) {
            //        NSLog(@"koordiy: %@",string);
            if (!yArray) {
                yArray=[[NSMutableArray alloc]init];
            }
            [bothCoordinates addObject:string];
            [yArray addObject:string];
            [something appendString:string];
            [putcoordstogether appendString:string];
            if (!coordinatesForFocusing3) {
                coordinatesForFocusing3 = [[NSMutableArray alloc]init];
            }
            [coordinatesForFocusing3 addObject:something];
            something = nil;
            
            if (!bothCoordsTogether3) {
                bothCoordsTogether3=[[NSMutableArray alloc]init];
            }
            [bothCoordsTogether3 addObject:putcoordstogether];
            putcoordstogether=nil;
            y=nil;
        }
    }
    
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    
    if([elementName isEqualToString:@"coords"]){
        elementname=@"perkele";
        secondcords = 2;
        return;
    }
    if ([elementName isEqualToString:@"shape"]) {
        shapeBool = NO;
    }
    
    if ([elementName isEqualToString:@"legs"]) {
        intForRoutes++;
        
    }
    if ([elementName isEqualToString:@"type"]) {
        types = nil;
    }
}


-(IBAction)searchAddress{
    
    if (self.bothCoordsTogether != nil) {
        self.bothCoordsTogether = nil;
    }
    if (bothCoordsTogether2 != nil) {
        bothCoordsTogether2 = nil;
    }
    if (bothCoordsTogether3 != nil) {
        bothCoordsTogether3 = nil;
    }
    if (coordinatesForFocusing != nil) {
        coordinatesForFocusing = nil;
    }
    if (coordinatesForFocusing2 != nil) {
        coordinatesForFocusing2 = nil; 
    }
    if (coordinatesForFocusing3 != nil) {
        coordinatesForFocusing3 = nil;
    }
    NSString *urlString1 = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=geocode&key=%@&user=neo_ati&pass=vumi_18&format=xml&epsg_out=4326", [addressField.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    // build the string with 'to" input field
    NSString *urlString2 = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=geocode&key=%@&user=neo_ati&pass=vumi_18&format=xml&epsg_out=4326", [addressFieldTo.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    BOOL success;
    // init and alloc nsurl with the 'from' string and get the content of it, then parse it with xml parser
    NSURL *url1 = [[NSURL alloc] initWithString:urlString1];
    xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url1];
    [xmlParser setDelegate:self];
    success=[xmlParser parse];
    
    // init and alloc nsurl with the 'to' string and get the content of it, then parse it with xml parser
    NSURL *url2 = [[NSURL alloc]initWithString:urlString2];
    xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url2];
    [xmlParser setDelegate:self];
    success=[xmlParser parse];
    
    
    
    NSArray *listItems1 = [coords1 componentsSeparatedByString:@","];
    NSArray *listItems2 = [coords2 componentsSeparatedByString:@","];
    coords1=nil;
    coords2=nil;
    elementname=nil;
    secondcords=0;
    
    double latitude = 0;
    double longitude = 0;
    double latitude2 = 0;
    double longitude2 = 0;
    
    if([listItems1 count] >= 2) {
        longitude = [[listItems1 objectAtIndex:0] doubleValue];
        latitude = [[listItems1 objectAtIndex:1] doubleValue];
    }
    //    NSLog(@"lati: %.10f",latitude);
    //    NSLog(@"long: %.10f",longitude);
    
    
    if([listItems2 count] >= 2) {
        longitude2 = [[listItems2 objectAtIndex:0] doubleValue];
        latitude2 = [[listItems2 objectAtIndex:1] doubleValue];
    }
    // Converting double to a string did something funny to the last decimals, limiting the number of decimals helped
    NSMutableString *latstring1 = [NSMutableString stringWithFormat:@"%g",latitude];
    NSMutableString *lonstring1 = [NSMutableString stringWithFormat:@"%g",longitude];
    
    NSMutableString *latstring2 = [NSMutableString stringWithFormat:@"%g",latitude2];
    NSMutableString *lonstring2 = [NSMutableString stringWithFormat:@"%g",longitude2];
    
    //    NSMutableArray *createdTime = @"%@",[time text];
    
    NSMutableString *createdTime = [[NSMutableString alloc]initWithString:[time text]];
    NSRange hei;
    hei = [createdTime rangeOfString:@":"];
    if (hei.location==NSNotFound) {
        
    }else{
        [createdTime deleteCharactersInRange: [createdTime rangeOfString: @":"]];
    }
    
    NSLog(@" time %@",createdTime);
    
    //putting together the url for route
    NSString *reitti = [NSString stringWithFormat:@"http://api.reittiopas.fi/hsl/prod/?request=route&from=%@,%@&to=%@,%@&user=neo_ati&pass=vumi_18&detail=full&format=xml&epsg_in=4326&epsg_out=4326&show=3&time=%@&timetype=%@",[lonstring1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[latstring1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[lonstring2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[latstring2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],createdTime,theTimeType];
    
    NSLog(@"Reitti: %@",reitti);
    
    boolean=NO;
    
    intForRoutes = 1;
    // Get the content of url with route url and parse it with xml parser.
    NSURL *url3 = [[NSURL alloc] initWithString:reitti];
    xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url3];
    [xmlParser setDelegate:self];
    success=[xmlParser parse];
    [addressField resignFirstResponder];
    [addressFieldTo resignFirstResponder];
    [time resignFirstResponder];
    
    
    NSLog(@"%@",firstRoute);
    NSLog(@"%@",secondRoute);
    NSLog(@"%@",thirdRoute);
    /*
    NSLog(@"%@",bothCoordsTogether);
    NSLog(@"%@",bothCoordsTogether2);
    NSLog(@"%@",bothCoordsTogether3);
    
    NSLog(@"%@",coordinatesForFocusing);
    NSLog(@"%@",coordinatesForFocusing3);
     */

    
    [self.table reloadData];
    
    
    
}

-(IBAction)timeType:(id)sender{
    switch (((UISegmentedControl *)sender).selectedSegmentIndex) {
        case 0:
            if (!theTimeType) {
                theTimeType = [[NSMutableString alloc]initWithString:@"departure"];
            }
            theTimeType = [NSMutableString stringWithFormat:@"departure"];
            break;
        case 1:
            if (!theTimeType) {
                theTimeType = [[NSMutableString alloc]initWithString:@"arrival"];
            }
            theTimeType = [NSMutableString stringWithFormat:@"arrival"];
            break;
            
            
        default:
            break;
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    
    return 3;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
       static NSString *CellIdentifier = @"Cell";
    
	static NSInteger picture1 = 1;
	static NSInteger picture2 = 2;
    // static NSInteger picture3 = 3;
	
    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:CellIdentifier];
    
    /*
     if (cell == nil) {
     cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
     }
     */
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    hello = 0;
    CGRect frame;
    frame.origin.x = 10; 
    frame.origin.y = 5;
    frame.size.height = 25;
    frame.size.width = 30;
    
    if ([indexPath row]==0) {
        for (hello=0; hello< [firstRoute count]; hello++) {
            
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"walk"]) {
                
                UIImageView *picture11 = [[UIImageView alloc]initWithFrame:frame];
                [picture11 setImage:[UIImage imageNamed:@"walk.png"]];
                picture11.tag = picture1;
                [cell.contentView addSubview:picture11];
                picture11 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"12"]) {
                
                
                UIImageView *picture22 = [[UIImageView alloc]initWithFrame:frame];
                [picture22 setImage:[UIImage imageNamed:@"train.png"]];
                picture22.tag = picture2;
                [cell.contentView addSubview:picture22];
                picture22 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"1"]||[[firstRoute objectAtIndex:hello] isEqualToString:@"3"]||[[firstRoute objectAtIndex:hello] isEqualToString:@"4"]||[[firstRoute objectAtIndex:hello] isEqualToString:@"8"]||[[firstRoute objectAtIndex:hello] isEqualToString:@"5"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"bus.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"2"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"tram.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"6"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"subway.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[firstRoute objectAtIndex:hello] isEqualToString:@"7"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"ferry.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            
        }
        firstRoute = nil;
    }
    
    if ([indexPath row]==1) {
        for (hello=0; hello< [secondRoute count]; hello++) {
            
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"walk"]) {
                
                UIImageView *picture11 = [[UIImageView alloc]initWithFrame:frame];
                [picture11 setImage:[UIImage imageNamed:@"walk.png"]];
                picture11.tag = picture1;
                [cell.contentView addSubview:picture11];
                picture11 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"12"]) {
                
                
                UIImageView *picture22 = [[UIImageView alloc]initWithFrame:frame];
                [picture22 setImage:[UIImage imageNamed:@"train.png"]];
                picture22.tag = picture2;
                [cell.contentView addSubview:picture22];
                picture22 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"1"]||[[secondRoute objectAtIndex:hello] isEqualToString:@"3"]||[[secondRoute objectAtIndex:hello] isEqualToString:@"4"]||[[secondRoute objectAtIndex:hello] isEqualToString:@"8"]||[[secondRoute objectAtIndex:hello] isEqualToString:@"5"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"bus.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"2"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"tram.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"6"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"subway.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[secondRoute objectAtIndex:hello] isEqualToString:@"7"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"ferry.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            
        } 
        secondRoute = nil;
    }
    if ([indexPath row]==2) {
        for (hello=0; hello< [thirdRoute count]; hello++) {
            
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"walk"]) {
                
                UIImageView *picture11 = [[UIImageView alloc]initWithFrame:frame];
                [picture11 setImage:[UIImage imageNamed:@"walk.png"]];
                picture11.tag = picture1;
                [cell.contentView addSubview:picture11];
                picture11 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"12"]) {
                
                
                UIImageView *picture22 = [[UIImageView alloc]initWithFrame:frame];
                [picture22 setImage:[UIImage imageNamed:@"train.png"]];
                picture22.tag = picture2;
                [cell.contentView addSubview:picture22];
                picture22 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"1"]||[[thirdRoute objectAtIndex:hello] isEqualToString:@"3"]||[[thirdRoute objectAtIndex:hello] isEqualToString:@"4"]||[[thirdRoute objectAtIndex:hello] isEqualToString:@"8"]||[[thirdRoute objectAtIndex:hello] isEqualToString:@"5"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"bus.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"2"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"tram.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"6"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"subway.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            if ([[thirdRoute objectAtIndex:hello] isEqualToString:@"7"]) {
                
                UIImageView *picture33 = [[UIImageView alloc]initWithFrame:frame];
                [picture33 setImage:[UIImage imageNamed:@"ferry.png"]];
                [cell.contentView addSubview:picture33];
                picture33 = nil;
                frame.origin.x += 40;
                frame.size.width = 30;
                frame.size.height = 25;
                
            }
            
        }
        thirdRoute = nil;
    }
    
        return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        selectedRow = 1;
        
        
    }
    if (indexPath.row == 1) {
        selectedRow = 2;
        
    }
    if (indexPath.row == 2) {
        selectedRow = 3;
    }
    MapView *map = [[MapView alloc]initWithNibName:@"MapView" bundle:nil];
    [self presentModalViewController:map animated:YES];
    map.bothCoordFromJourneyPlanner1=self.bothCoordsTogether;
    map.bothCoordFromJourneyPlanner2 = bothCoordsTogether2;
    map.bothCoordFromJourneyPlanner3 = bothCoordsTogether3;
    map.coordsForFocusFromJR = coordinatesForFocusing;
    map.coordsForFocusFromJR2 = coordinatesForFocusing2;
    map.coordsForFocusFromJR3 = coordinatesForFocusing3;
    map.checkrow=selectedRow;
    map.addFromJR = addressField.text;
    map.addToJR = addressFieldTo.text;
    
//    NSLog(@"%@",self.bothCoordsTogether);
    /*
    DetailViewController *detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:[NSBundle mainBundle]];
    // ...
    // Pass the selected object to the new view controller.
    Event *selectedObject = [[self fetchedResultsController] objectAtIndexPath:indexPath];
    
    NSLog(@"object selected: %@",selectedObject);
    
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController showView:selectedObject];
    */
	
}


-(void)viewDidAppear:(BOOL)animated{
    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
