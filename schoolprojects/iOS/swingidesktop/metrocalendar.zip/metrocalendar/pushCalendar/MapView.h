//
//  MapView.h
//  pushCalendar
//
//  Created by iosdev on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mapAnnotation.h"
#import<MapKit/MapKit.h>
#import "JourneyPlanner.h"

@interface MapView : UIViewController<MKMapViewDelegate, NSXMLParserDelegate>{
    JourneyPlanner *journeyplanner;
    
	IBOutlet UITextField *addressField;
    IBOutlet UITextField *addressFieldTo;
	IBOutlet UIButton *goButton;
	IBOutlet MKMapView *mapView;
	NSXMLParser *xmlParser;
	mapAnnotation *addAnnotation;
    // CLLocationCoordinate2D doit;
    CLLocationCoordinate2D fromLocationTextField;
    CLLocationCoordinate2D toLocationTextField;
    int secondcords;
    int legs;
    NSString *elementname;
    NSString *x;
    NSString *y;
    NSString *as;
    NSMutableArray *xArray;
    NSMutableArray *yArray;
    NSMutableString *putcoordstogether;
    NSMutableArray *bothCoordinates;
    NSMutableArray *bothCoordsTogether;
    NSMutableString *coords1;
    NSMutableString *coords2;
    NSMutableString *something;
    BOOL boolean;
    NSMutableArray *overLays;
    MKMapView* _mapView;
	MKPolyline* _routeLine;
    NSArray *endAndStartAnnotation;
	MKPolylineView* _routeLineView;
	MKMapRect makeRectangleAroundRoute;
    
    BOOL booleanForTrasportType;
    NSString *transportType;
    NSMutableArray *coordinatesForFocusing;
    //---uusia viivoja----
    NSMutableArray *routesArray;
    NSMutableArray *walkingLines;
    NSMutableArray *transports;
    int i;
    int i2;
    int checkrow;
    
    NSMutableArray *bothCoordFromJourneyPlanner1;
    NSMutableArray *bothCoordFromJourneyPlanner2;
    NSMutableArray *bothCoordFromJourneyPlanner3;
    NSMutableArray *coordsForFocusFromJR;
    NSMutableArray *coordsForFocusFromJR2;
    NSMutableArray *coordsForFocusFromJR3;
    NSString *addFromJR;
    NSString *addToJR;
    
}
@property (nonatomic, strong) MKPolyline* routeLine;
@property (nonatomic, strong) MKPolylineView* routeLineView;
@property (nonatomic, strong) IBOutlet MKMapView* mapView;
@property (nonatomic) int checkrow;
@property (nonatomic,strong) JourneyPlanner *journeyplanner;
@property (nonatomic,strong) NSMutableArray *bothCoordFromJourneyPlanner1;
@property (nonatomic,strong) NSMutableArray *bothCoordFromJourneyPlanner2; 
@property (nonatomic,strong) NSMutableArray *bothCoordFromJourneyPlanner3;
@property (nonatomic,strong) NSMutableArray *coordsForFocusFromJR;
@property (nonatomic,strong) NSMutableArray *coordsForFocusFromJR2;
@property (nonatomic,strong) NSMutableArray *coordsForFocusFromJR3;
@property (nonatomic,strong) NSString *addFromJR;
@property (nonatomic,strong) NSString *addToJR;
- (IBAction) showAddress;
-(id) loadRoute;
// use the computed _routeRect to zoom in on the route. 
-(void) zoomInOnRoute;
-(IBAction)clear;
-(IBAction)mapChoice:(id)sender;
-(CLLocationCoordinate2D) addressLocation;


@end
