//
//  userViewController.m
//  coreProject
//
//  Created by iosdev on 11/21/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "userView.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>
#import "newGroupViewController.h"

#import "DatePickView.h"

@implementation userView

@synthesize txtFieldFirstName, txtFieldLastName, txtFieldEmail, txtFieldPassword, txtFieldConfirmPassword, showCharacter, scrollView, status;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(IBAction)profileSave{
    
    NSError *error;
    
    if([txtFieldFirstName.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"First name cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    
        
    }
    else if([txtFieldLastName.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"Last name cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    
        
    }
    else if ([txtFieldEmail.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"Email cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    }
    else if([txtFieldPassword.text isEqualToString:@""]) 
    {
        UIAlertView *alert =
        [[UIAlertView alloc] initWithTitle:@"Error"
                                   message:@"password cant be empty."
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        [alert show];    
        
    }
    else
    {

                
        if ([txtFieldPassword.text isEqualToString:@""])
        {
            status.text = @"Insert Password!";
        }
        else if([txtFieldPassword.text isEqualToString:txtFieldConfirmPassword.text])
        {
            NSLog(@"Passwords are same");
            NSLog(@"regpass: %@", txtFieldPassword.text);
            NSLog(@"conpass: %@", txtFieldConfirmPassword.text);
            

            AppDelegate *appDelegate =(AppDelegate *)[[UIApplication sharedApplication] delegate];
            NSManagedObjectContext *context = [appDelegate managedObjectContext];
            NSManagedObjectModel *newUser;
            newUser = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:context];
            [newUser setValue:txtFieldFirstName.text forKey:@"firstName"];
            NSLog(@"firstName is given");
            [newUser setValue:txtFieldLastName.text forKey:@"lastName"];
            [newUser setValue:txtFieldEmail.text forKey:@"email"];
            [newUser setValue:txtFieldPassword.text forKey:@"password"];
            

            
            NSString *urlString = [NSString stringWithFormat:@"http://ec2-204-236-207-173.compute-1.amazonaws.com/test/save_user.php?email=%@&password=%@",txtFieldEmail.text,txtFieldPassword.text];
            
            
            
            NSURL *url = [[NSURL alloc] initWithString:urlString];
            
            NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
            
            NSURLResponse *response;
            
            
            
            NSString *responseData= [[NSString alloc] initWithData:[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error] encoding:NSUTF8StringEncoding]; 
            
            NSLog(@"server response is %@\n", responseData);
            
            NSMutableString *strippedString = [NSMutableString 
                                               stringWithCapacity:responseData.length];
            NSScanner *scr = [[NSScanner alloc] initWithString:responseData];
            
            NSCharacterSet *numbers = [NSCharacterSet 
                                       characterSetWithCharactersInString:@"0123456789"];
            
            while ([scr isAtEnd] == NO) 
            {
                NSString *buffer;
                if ([scr scanCharactersFromSet:numbers intoString:&buffer])
                {
                    [strippedString appendString:buffer];
                    
                }
                else 
                {
                    [scr setScanLocation:([scr scanLocation] + 1)];
                }
            }
            
            NSLog(@"%@", strippedString);
           
            
            NSNumber *num = [NSNumber numberWithInteger: [strippedString integerValue]];
            int con;
             con = [num intValue];
            
             NSLog(@"con is: %i", con);
            
            if (con == 1)
            {
                UIAlertView *alert =
                [[UIAlertView alloc] initWithTitle:@"Error"
                                           message:@"Email already exists."
                                          delegate:nil
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
                [alert show]; 
            
                txtFieldEmail.text = nil;
                txtFieldPassword.text = nil;
                txtFieldConfirmPassword.text = nil;
                
            }

            else if(con > 0)
            {
            
                [newUser setValue:num forKey:@"userID"];
                [context save:&error];
                
                
                
                UIAlertView *alert =
                [[UIAlertView alloc] initWithTitle:@""
                                           message:@"account created successfully."
                                          delegate:nil
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
                [alert show];    
                
                [self dismissModalViewControllerAnimated:YES];
                
            }
            
            
            NSFetchRequest *request = [[NSFetchRequest alloc]init];
            NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"User" inManagedObjectContext:context];
            [request setEntity:entityDesc];
            //NSPredicate *pred = [NSPredicate predicateWithFormat:@"(email = %@)",txtFieldEmail.text];
            //[request setPredicate:pred];
            NSArray *objects = [context executeFetchRequest:request error:&error];
            NSLog(@"Fetch request is executed");
            NSLog(@"%d",[objects count]);
            
        }
        else
        {
            NSLog(@"Passwords are wrong");UIAlertView *alert =
            [[UIAlertView alloc] initWithTitle:@"Error"
                                       message:@"passwords dont match."
                                      delegate:nil
                             cancelButtonTitle:nil
                             otherButtonTitles:@"OK", nil];
            [alert show]; 
            
            txtFieldPassword.text = nil;
            txtFieldConfirmPassword.text = nil;
            
        }
    }
}

-(IBAction)Back
{
    [self dismissModalViewControllerAnimated:YES];
}



-(IBAction)onOroff{
    if(!showCharacter.on){
        [txtFieldPassword setSecureTextEntry:NO];
        [txtFieldConfirmPassword setSecureTextEntry:NO];
        NSLog(@"Switch is off");
    }else{
        [txtFieldPassword setSecureTextEntry:YES];
        [txtFieldConfirmPassword setSecureTextEntry:YES];
        NSLog(@"Switch is on");
    }
}



- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    
    [self onOroff];
    self.view.backgroundColor = [UIColor grayColor];
    scrollView.frame = CGRectMake(0, 0, 320, 460);
    [scrollView setContentSize:CGSizeMake(320, 678)];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
}
*/
@end
