//
//  newGroupViewController.h
//  coreProject
//
//  Created by iosdev on 11/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class userViewController;
@interface newGroupViewController : UIViewController{
    UITextField *groupName;
    UITextField *contactName;
}

@property(nonatomic,strong) IBOutlet UITextField *groupName;
@property(nonatomic,strong) IBOutlet UITextField *contactName;
-(IBAction)parentView;
@end
