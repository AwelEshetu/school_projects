//
//  FirstViewController.m
//  MetroCalendar
//
//  Created by iosdev on 11/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import "FirstViewController.h"
#import "AppDelegate.h"
#import "AddEvent.h"
#import "XMLParserGroup.h"
#import "CalendarView.h"
#import "DetailViewController.h"
#import "UserView.h"



@implementation FirstViewController
@synthesize cVc;
@synthesize eventView;
 



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Calendar", @"Calendar");
        self.tabBarItem.image = [UIImage imageNamed:@"83-calendar"];
         
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}


-(void)EventAdd{
    AddEvent *ae = [[AddEvent alloc] initWithNibName:@"AddEvent" bundle:nil];
    [self.navigationController pushViewController:ae animated:YES];
    
}


-(void)highlightSelectedDate{
    
    SelectedDate = [[UIView alloc]initWithFrame:selectedDatePoint];
    SelectedDate.backgroundColor = [UIColor colorWithRed:0.1 green:0.5 blue:0.1 alpha:0.2];
    [self.view addSubview:SelectedDate];
    
    
}

-(void)createTable{
    CGRect tableViewRect = CGRectMake(0, 290, 320, 150);
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:tableViewRect style:UITableViewStylePlain];
    self.eventView =tableView;
    [self.view addSubview:eventView];
    self.eventView.dataSource=self;
    self.eventView.delegate =self;
    
}









- (void)myTap:(UIGestureRecognizer *)sender {
    CGPoint location = [sender locationInView:self.view];
    
    int x,y;
    
    int weekday=[cVc getMonthWeekday:cVc.currentMonthDate];
    int monthDayCount=[cVc getDayCountOfaMonth:cVc.currentMonthDate];
    NSString *mitti;
    
    x=((location.x-40)*7)/280 ;
    
    y=(location.y-80)/35;
    int monthday=x+y*7-weekday+2;
    if(monthday>0 && monthday<monthDayCount+1){
        mitti = [NSString stringWithFormat:@"%d-%d-%d",cVc.currentMonthDate.year,cVc.currentMonthDate.month,monthday];
        
        AddEvent *addEvent = [[AddEvent alloc] initWithNibName:@"AddEvent" bundle:nil];
        
        [self.navigationController pushViewController:addEvent animated:YES];
        NSLog(@"mitti=%@",mitti);
        //addEvent.dateText.text=mitti;
        
        //  [self highlightSelectedDate];
        [cVc HasAnyEvent];
        [self.cVc setNeedsDisplay];
        
        //  [eventView reloadData];
    }
    
    
    
}
- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	int width=320;
    int x,y;
    
	UITouch* touch=[touches anyObject];
	CGPoint touchPoint=[touch locationInView:self.view];
    
    
    x=((touchPoint.x-40)*7)/280 ;
    
    y=(touchPoint.y-80)/35;
    
	if(touchPoint.x<40 && touchPoint.y<40)
		[cVc movePrevMonth];
	else if(touchPoint.x>width-40 && touchPoint.y<40)
		[cVc moveNextMonth];
    [SelectedDate removeFromSuperview];
    [eventView removeFromSuperview];  
    
    
}



-(void)myTapToSelect:(UIGestureRecognizer *)sender{
    
    [eventView removeFromSuperview];
    [SelectedDate removeFromSuperview];
    
    NSString *mitti;
    int dateCountsFromServer;
    CGPoint location = [sender locationInView:self.view];
    int x=((location.x-40)*7)/280;
    int y=(location.y-80)/35;
    int s_width =40;
    
    int weekday = [cVc getMonthWeekday:cVc.currentMonthDate];
    int monthDayCount=[cVc getDayCountOfaMonth:cVc.currentMonthDate];
    
    int monthday=x+y*7-weekday+2;
    NSLog(@"check tapped date%d",monthday);
    NSLog(@"check the cordinate x%f y% f",location.x,location.y);
    
    
    if(monthday>0 && monthday<monthDayCount+1){
        CGRect highlightSelectedDate = CGRectMake(x*s_width+s_width,  y*35+80, 40, 35);
        selectedDatePoint = highlightSelectedDate;
        /* SelectedDate = [[UIView alloc]initWithFrame:highlightSelectedDate];
         SelectedDate.backgroundColor = [UIColor colorWithRed:0.1 green:0.5 blue:0.1 alpha:0.2];
         [self.view addSubview:SelectedDate];*/
        [self highlightSelectedDate];
        int placeZero=0;
        if(monthday <=9)
            mitti = [NSString stringWithFormat:@"%d-%d-%d%d",cVc.currentMonthDate.year,cVc.currentMonthDate.month,placeZero,monthday];
        else
            mitti = [NSString stringWithFormat:@"%d-%d-%d",cVc.currentMonthDate.year,cVc.currentMonthDate.month,monthday];
        NSLog(@"la check gar tap date%@",mitti);
        
        //Core Data Begins
        holdMiti = mitti;
        
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        NSManagedObjectContext *context = [appDelegate managedObjectContext];
        NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:context];
        NSFetchRequest *request = [[NSFetchRequest alloc]init];
        [request setEntity:entityDesc];
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"(date=%@)",mitti];
        [request setPredicate:pred];
        //  NSLog(@"k aauchha ho:%@",pred);
        NSError *error;
        NSManagedObject *matches = nil;
        NSArray *objects = [context executeFetchRequest:request error:&error];
        
        
        
        NSInteger countMatchObject=[objects count];
        
        int counter=0;
        collectDate = [[NSMutableArray alloc]init];
        
        holdTitle = [[NSMutableArray alloc]init ];
        while (countMatchObject!=0) {
            matches = [objects objectAtIndex:counter];
            counter++;
            NSString *dateString=[matches valueForKey:@"date"];
            
            NSString *eventTitle = [matches valueForKey:@"title"];      
            
            countMatchObject--;
            
            [holdTitle addObject:eventTitle];
            
            [collectDate addObject:dateString];
            
            
            
        }
        
        dateCountsFromServer= [collectDate count];
        
        
        // core Data Ends
        //  BOOL presentTableView;
        for (int checktime = dateCountsFromServer-1; checktime>=0;checktime--) {
            
            if ([mitti isEqualToString:[collectDate objectAtIndex:checktime]]) { 
                NSLog(@"myTap. x = %f, y = %f", location.x, location.y);
                countEventOnaDay=[collectDate count];
                //  presentTableView =YES;
                NSLog(@"check matching date%@",collectDate);               
                NSLog(@"count event on a day 1 %d",countEventOnaDay);                
                
            }
            NSLog(@"HoldTitle gives this %@", holdTitle);
        } 
        
        //  if(presentTableView==YES){
        // presentTableView = NO;
        /* CGRect tableViewRect = CGRectMake(0, 290, 320, 150);
         
         UITableView *tableView = [[UITableView alloc]initWithFrame:tableViewRect style:UITableViewStylePlain];
         self.eventView =tableView;
         [self.view addSubview:eventView];
         self.eventView.dataSource=self;
         self.eventView.delegate =self;*/
        [self createTable];
        [eventView reloadData];
        //}
        
        // presentTableView = NO;
        
        
    }
    
    
    
}
//Next Swipe Function

-(void)NextSwipes:(UISwipeGestureRecognizer *)sender{
    
    
    if(sender.direction & UISwipeGestureRecognizerDirectionLeft){
        [cVc moveNextMonth];
        [eventView removeFromSuperview];
        [SelectedDate removeFromSuperview];
    }
    
    NSLog(@"here i am left swiped");
} 

//Prev Swipe Function
-(void)PrevSwipes:(UISwipeGestureRecognizer *)sender{
    
    
    if(sender.direction & UISwipeGestureRecognizerDirectionRight){
        [cVc movePrevMonth]; 
        [eventView removeFromSuperview];
        [SelectedDate removeFromSuperview];
    }
    
    NSLog(@"here i am right swiped");
    
    
    
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    
    CGRect touchFrame = CGRectMake(40, 80, 320, 205);
    UIView *touchView = [[UIView alloc]initWithFrame:touchFrame];
    //touchView.backgroundColor = [UIColor colorWithRed:0.1 green:0.5 blue:0.1 alpha:0.9]; 
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myTap:)];
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myTapToSelect:)];
    tap.numberOfTapsRequired = 2;
    tap1.numberOfTapsRequired =1;
    [touchView addGestureRecognizer:tap];
    [touchView  addGestureRecognizer:tap1];
    [self.cVc addSubview:touchView];
    [self.cVc addSubview:touchView];
    
    /* Swipe Functionalities*/
    UISwipeGestureRecognizer *swipeGestureRecognizerNext = [[UISwipeGestureRecognizer alloc]
                                                            initWithTarget:self action:@selector(NextSwipes:)];
    UISwipeGestureRecognizer *swipeGestureRecognizerPrev = [[UISwipeGestureRecognizer alloc]
                                                            initWithTarget:self action:@selector(PrevSwipes:)];
    /* Swipes that are performed from right to
     left are to be detected */
    swipeGestureRecognizerNext.direction = UISwipeGestureRecognizerDirectionLeft;
    
    /* Just one finger needed */ 
    swipeGestureRecognizerNext.numberOfTouchesRequired = 1;
    /* Add it to the view */
    [self.cVc addGestureRecognizer:swipeGestureRecognizerNext];
    
    
    //Prev Swipe
    
    swipeGestureRecognizerPrev.direction = UISwipeGestureRecognizerDirectionRight;
    
    /* Just one finger needed */ 
    swipeGestureRecognizerPrev.numberOfTouchesRequired = 1;
    /* Add it to the view */
    [self.cVc addGestureRecognizer:swipeGestureRecognizerPrev];
    // Swipe Ends Here
    
    
    
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    UILabel *label = [[UILabel alloc] init];
    label.font = [UIFont fontWithName:@"Helvetica-Bold" size: 25.0];
    [label setBackgroundColor:[UIColor clearColor]];
    [label setTextColor:[UIColor brownColor]];
    [label setText:@"Metro Calendar"];
    [label sizeToFit];
    [self.navigationController.navigationBar.topItem setTitleView:label];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    
    
    
    
      
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(EventAdd)];
    
    
    
    //    
    //    [[self parentViewController] navigationItem].rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCamera target:self action:@selector(buttonGroup)];
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    //[[self parentViewController] setTitle:@"Metro Calendar"];
    [self.cVc setNeedsDisplay]; 
   // [cVc HasAnyEvent];
    [self highlightSelectedDate];
    [eventView reloadData];
    
    
    
}


- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    [SelectedDate removeFromSuperview];
    // [eventView removeFromSuperview];
    
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
    // [eventView removeFromSuperview];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}



#pragma mark Table view methods



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return  1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if ([collectDate count]>0) {
        return [collectDate count];
    }
    else
        return 1;
    
    
    
    
    
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    static NSString *CellIdentifier = @"Cell";
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
	
    // Set up the cell...
    cell.textLabel.font = [UIFont boldSystemFontOfSize:12];
    if ([collectDate count]==0) {
        cell.textLabel.text =@"No Item";
    }
    else
        cell.textLabel.text = [NSString	 stringWithFormat:@"%@", [holdTitle objectAtIndex:indexPath.row]];
    
    
    return cell;
    
    
    
}
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // The table view should not be re-orderable.
    
    return YES;
    
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	// open a alert with an OK and cancel button
    NSMutableDictionary *dataPass = [[NSMutableDictionary alloc]init ];
    
    DetailViewController *detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:[NSBundle mainBundle]];
    
    
    
    Event *selectedObject = dataPass;
    
    if (([holdTitle count]==0)) {
        NSLog(@"Nothing to pass");
        AddEvent *addEvent =[[AddEvent alloc]initWithNibName:@"AddEvent" bundle:nil];
        [self.navigationController pushViewController:addEvent animated:YES];
        NSLog(@"check holdmiti%@",holdMiti);
        //addEvent.dateText.text = holdMiti;
        
    }
    else{
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        NSManagedObjectContext *context = [appDelegate managedObjectContext];
        NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:context];
        NSFetchRequest *request = [[NSFetchRequest alloc]init];
        [request setEntity:entityDesc];
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"(title=%@)",[holdTitle objectAtIndex:indexPath.row]];
        [request setPredicate:pred];
        //  NSLog(@"k aauchha ho:%@",pred);
        NSError *error;
        NSManagedObject *matches = nil;
        NSArray *objects = [context executeFetchRequest:request error:&error];
        matches = [objects objectAtIndex:0];
        
        NSString *dateString=[matches valueForKey:@"date"];
        
        NSString *eventTitle = [matches valueForKey:@"title"];
        NSNumber * eventID= [matches valueForKey:@"eventID"];
        NSNumber *description= [matches valueForKey:@"eventDescription"];
        
                
        [dataPass setValue:eventTitle forKey:@"title"];
        [dataPass setValue:dateString forKey:@"date"]; 
        [dataPass setValue:description forKey:@"eventDescription"]; 
        
        [dataPass setValue:eventID forKey:@"eventID"];
                
        [self.navigationController pushViewController:detailViewController animated:YES];
        [detailViewController showView:selectedObject];
    }
    
    
    
}



@end
