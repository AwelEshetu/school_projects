//
//  userViewController.h
//  coreProject
//
//  Created by iosdev on 11/21/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userView : UIViewController{
   
    IBOutlet UILabel *Response;
    
    UIScrollView *scrollView;
    UITextField *txtFieldFirstName;
    UITextField *txtFieldLastName;
    UITextField *txtFieldEmail;
    UITextField *txtFieldPassword;
    UITextField *txtFieldConfirmPassword;
    UISwitch *showCharacter;
    UILabel *status;
    
}

@property(nonatomic,strong) IBOutlet UIScrollView *scrollView;
@property(nonatomic, strong) IBOutlet UITextField *txtFieldFirstName;
@property(nonatomic, strong) IBOutlet UITextField *txtFieldLastName;
@property(nonatomic, strong) IBOutlet UITextField *txtFieldEmail;
@property(nonatomic, strong) IBOutlet UITextField *txtFieldPassword;
@property(nonatomic, strong) IBOutlet UITextField *txtFieldConfirmPassword;
@property(nonatomic, strong) IBOutlet UISwitch *showCharacter;
@property(nonatomic, strong) IBOutlet UILabel *status;


-(IBAction)profileSave;
-(IBAction)onOroff;
-(IBAction)Back;

@end
