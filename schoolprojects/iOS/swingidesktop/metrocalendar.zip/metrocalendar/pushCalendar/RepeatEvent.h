//
//  RepeatEvent.h
//  pushCalendar
//
//  Created by iosdev on 11/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RepeatEvent : UIViewController
{
    
}

-(IBAction) back;

@end
