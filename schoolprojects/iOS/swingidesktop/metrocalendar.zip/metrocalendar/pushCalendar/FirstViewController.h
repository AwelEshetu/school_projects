//
//  FirstViewController.h
//  MetroCalendar
//
//  Created by iosdev on 11/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalendarView.h"
#import "AddEvent.h"
#import "Event.h"
#import "DetailViewController.h"


@interface FirstViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>{
    
    CalendarView *cVc;
    AddEvent *addDelegate;
    
    
    
    
    UITableView *eventView;
    UIView *SelectedDate ;
    
    NSMutableArray *collectDate;
    int countEventOnaDay;
    NSMutableArray *holdTitle;
    NSString *holdMiti;
    CGRect selectedDatePoint;
}
@property (nonatomic,strong) IBOutlet  CalendarView *cVc;
@property (nonatomic,strong)  UITableView *eventView;


@end