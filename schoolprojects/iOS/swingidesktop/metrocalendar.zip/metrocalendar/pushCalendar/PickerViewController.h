//
//  PickerViewController.h
//  test
//
//  Created by iosdev on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "EventSenderViewController.h"
#import "AddEvent.h"
//@class  EventSenderViewController;

@interface PickerViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource> {
	IBOutlet UIDatePicker *StartDatePicker;
	
    AddEvent *av;
	IBOutlet UILabel *StartD;
	IBOutlet UILabel *EndD;
    
}
-(IBAction)SaveStartTime:(id)Sender;
-(IBAction)SaveEndTime:(id)Sender;


@property (nonatomic, retain) AddEvent *av;
@property (nonatomic, retain) UILabel *StartD;
@property (nonatomic, retain) UIDatePicker *StartDatePicker;


@end
